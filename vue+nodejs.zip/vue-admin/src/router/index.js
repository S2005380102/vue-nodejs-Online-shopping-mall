
// import { from } from "core-js/core/array"
import { createWebHistory,createRouter } from "vue-router"

import store from "@/store"


const routes = [
    {
        name: 'admin_login',
        path: '/',
        component: () => import("@/admin/adminlogin.vue")
    },
    {
        name: 'admin_index',
        path: '/admin',
        component: () => import("@/admin/admin.vue"),
        children: [
            {
                name: 'GoodsAudit',
                path: '/admin/GoodsAudit',
                component: () => import("@/admin/GoodsAudit.vue")
            },
            {
                name: 'NewAdmin',
                path: '/admin/NewAdmin',
                component: () => import("@/admin/NewAdmin.vue")
            },
            {
                name: 'MerchantAudit',
                path: '/admin/MerchantAudit',
                component: () => import("@/admin/MerchantAudit.vue")
            },
    //         {
    //             name: 'admin_Edit',
    //             path: '/admin/adminEdit',
    //             component: () => import("@/admin/adminEdit.vue")
    //         },
          ]
    },
]

const router = createRouter({
    history: createWebHistory(),
    routes
})







//导航守卫
//to 去哪
//from 哪里来
//放行？

const authUrls = ['/admin', '/admin/GoodsAudit', '/admin/NewAdmin']


router.beforeEach((to, from, next) => {

    // console.log(to,from,next)
    //非权限页面放行
    if (!authUrls.includes(to.path)) {
        next();
        return

    }
    //权限页面，需要token
    const token = store.getters.token
    if (token) {
        next()
    } else {
        alert("请先登录");
        console.log(token)
        next('/')
    }

    console.log(token)

    
})









export default router




