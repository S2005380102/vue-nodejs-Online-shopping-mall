<template>
  <div class="GoodsAudit">
    <header>
      <h1>文章管理</h1>
    </header>
    <button @click="showAddArticleForm = true">新增文章</button>
    <div class="content">
      <table class="goodsTable" v-if="!showAddArticleForm">
        <thead>
          <tr>
            <th>ID</th>
            <th>标题</th>
            <th>添加时间</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="article in articles" :key="article.id">
            <td>{{ article.id }}</td>
            <td>{{ article.title }}</td>
            <td>{{ new Date(article.time).toLocaleString() }}</td>
            <td>
              <button @click="editArticle(article.id)">编辑</button>
              <button @click="deleteArticle(article.id)" class="danger">
                删除
              </button>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- 新增/编辑文章表单（简化版） -->
      <div v-if="showAddArticleForm" class="article-form">
        <h2>{{ editArticleId ? "编辑文章" : "新增文章" }}</h2>
        <form @submit.prevent="submitArticle">
          <input v-model="articleTitle" placeholder="文章标题" required />
          <textarea
            v-model="articleContent"
            placeholder="文章内容"
            required
          ></textarea>
          <button type="submit">
            {{ editArticleId ? "保存修改" : "发布文章" }}
          </button>
          <button @click="cancelEdit">取消</button>
        </form>
      </div>

      <ul class="pagination" v-if="!showAddArticleForm">
        <li
          v-for="page in totalPages"
          :key="page"
          :class="{ active: page === currentPage }"
        >
          <button @click="changePage(page)" :disabled="page === currentPage">
            {{ page }}
          </button>
        </li>
      </ul>
    </div>
  </div>
</template>
 
<script>
import axios from "axios";

export default {
  name: "NewAdmin",
  data() {
    return {
      articles: [], // 文章列表
      articleTitle: "", // 文章标题（用于新增/编辑）
      articleContent: "", // 文章内容（用于新增/编辑）
      editArticleId: null, // 当前正在编辑的文章ID
      showAddArticleForm: false, // 是否显示新增/编辑文章表单
      currentPage: 1, // 当前页码
      totalPages: 1, // 总页数
      articlesPerPage: 10, // 每页显示的文章数量
    };
  },
  methods: {
    async fetchArticles(page = 1) {
      try {
        const response = await axios.get("http://localhost:8081/api/newslist");
        const allArticles = response.data.data;

        // 计算总页数
        this.totalPages = Math.ceil(allArticles.length / this.articlesPerPage);

        // 根据页码和每页数量切片文章列表
        const startIndex = (page - 1) * this.articlesPerPage;
        const endIndex = startIndex + this.articlesPerPage;
        this.articles = allArticles.slice(startIndex, endIndex);

        // 设置当前页码
        this.currentPage = page;
      } catch (error) {
        console.error("获取文章列表失败:", error);
      }
    },
    changePage(page) {
      if (page >= 1 && page <= this.totalPages) {
        this.fetchArticles(page);
      }
    },
    async fetchArticleDetail(id) {
      // 用于编辑前的详情获取（当前示例中未完全使用，但展示了如何获取详情）
      try {
        const response = await axios.get(
          `http://localhost:8081/api/news/${id}`
        );
        const article = response.data.data[0];
        this.articleTitle = article.title;
        this.articleContent = article.content;
        this.editArticleId = article.id;
        this.showAddArticleForm = true; // 跳转到编辑模式
      } catch (error) {
        console.error("获取文章详情失败:", error);
      }
    },
    async editArticle(id) {
      this.fetchArticleDetail(id); // 获取详情并跳转到编辑模式
    },
    async deleteArticle(id) {
      try {
        // 构造要发送的数据
        const data = {
          id: id,
        };

        // 使用 axios 发送 POST 请求，并将数据作为请求体发送
        await axios.post(`http://localhost:8081/api/deletecart`, data);
        this.fetchArticles(); // 重新获取文章列表以刷新页面
      } catch (error) {
        console.error("删除文章失败:", error);
      }
    },
    async submitArticle() {
      try {
        const url = this.editArticleId
          ? "http://localhost:8081/api/updatenews"
          : "http://localhost:8081/api/addnews"; // 新增文章
        const data = {
          id: this.editArticleId || null,
          title: this.articleTitle,
          content: this.articleContent,
          author: this.$store.getters.admin,
        };
        // 由于方法始终是 POST，这里不需要动态选择方法
        const response = await axios.post(url, data);
        console.log(response);
        this.fetchArticles(); // 重新获取文章列表以刷新页面
        this.showAddArticleForm = false; // 关闭表单
        this.editArticleId = null; // 重置编辑状态
        this.articleTitle = ""; // 清空标题
        this.articleContent = ""; // 清空内容
      } catch (error) {
        console.error("提交文章失败:", error);
      }
    },
    cancelEdit() {
      this.showAddArticleForm = false; // 关闭表单
      this.editArticleId = null; // 重置编辑状态
      this.articleTitle = ""; // 清空标题
      this.articleContent = ""; // 清空内容
    },
  },
  mounted() {
    this.fetchArticles(); // 组件挂载时获取文章列表
  },
};
</script>

<style scoped lang="less">
.GoodsAudit {
  header {
    width: 100%;
    padding: 15px;
    background-color: #f8f9fa;
    border-bottom: 1px solid #ddd;
    h1 {
      margin: 0;
      font-size: 24px;
      text-align: center;
    }
  }

  .content {
    padding: 20px;
    .goodsTable {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
      th,
      td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;
      }
      th {
        background-color: #f2f2f2;
      }
      tbody tr:nth-child(even) {
        background-color: #f9f9f9;
      }
      td button {
        margin: 0 5px;
      }
      .danger {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
      }
    }
  }

  .article-form {
    background-color: #f8f9fa;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 5px;
    h2 {
      margin-top: 0;
      font-size: 20px;
    }
    form {
      display: flex;
      flex-direction: column;
      input,
      textarea {
        margin-bottom: 15px;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
      }
      button {
        padding: 10px;
        margin-top: 15px;
        border: none;
        background-color: #007bff;
        color: white;
        border-radius: 5px;
        cursor: pointer;
        &:hover {
          background-color: #0056b3;
        }
      }
    }
  }

  .pagination {
    display: flex;
    justify-content: center;
    list-style-type: none;
    padding: 0;
    li {
      margin: 0 5px;
      a,
      button {
        padding: 8px 16px;
        text-decoration: none;
        border: 1px solid #ddd;
        border-radius: 5px;
        color: #007bff;
        &:hover {
          background-color: #f1f1f1;
        }
      }
      &.active a,
      &.active button {
        background-color: #007bff;
        color: white;
        cursor: not-allowed;
      }
    }
  }
}
</style>