<template>
  <div class="Backstage">
    <div class="bsLeft">
      <div class="logo">More Mall</div>
      <ul class="ulnav">
        <li
          @click="navTo('/admin/MerchantAudit')"
          :class="{ selected: curPath === '/admin/MerchantAudit' }"
        >
          商家账号审核
        </li>
        <li
          @click="navTo('/admin/GoodsAudit')"
          :class="{ selected: curPath === '/admin/GoodsAudit' }"
        >
          商品审核
        </li>
        <li
          @click="navTo('/admin/NewAdmin')"
          :class="{ selected: curPath === '/admin/NewAdmin' }"
        >
          新闻管理
        </li>
      </ul>
    </div>
    <div class="bsRight">
      <div class="header">
        <div class="title">管理员管理系统</div>
        <div class="userInfo">
          当前用户：
          <span @mouseover="showUserTips" @mouseout="closeUserTips">{{
            admin
          }}</span>
          <span @click="logout">&nbsp;&nbsp;&nbsp; 退出</span>
        </div>
      </div>
      <transition name="router-fade" mode="out-in">
        <router-view
          :style="{
            overflowY: 'scroll',
            width: '100%',
            padding: '20px',
            backgroundColor: '#f6f5fa',
          }"
        ></router-view>
      </transition>
    </div>
  </div>
</template>

<script>
export default {
  name: "admin_index",
  data() {
    return {
      curPath: this.$route.path, // 初始化当前路径为当前路由的路径
      admin: null, // 初始化为 null 或从 store 中获取
      userTipsShow: false, // 可能需要添加这个数据来控制用户提示的显示
    };
  },
  watch: {
    // 监听路由变化以更新当前路径
    $route(to) {
      this.curPath = to.path;
    },
  },
  created() {
    this.admin = this.$store.getters.admin;
  },
  methods: {
    navTo(path) {
      this.$router.push(path);
    },
    logout() {
      // 实现注销逻辑
      this.$store.dispatch("clearadmin");
      // this.$router.replace("/");
      this.$router.push("/"); // 或其他登录页面路由
    },
    showUserTips() {
      this.userTipsShow = true;
    },
    closeUserTips() {
      this.userTipsShow = false;
    },
  },
};
</script>

<style scoped lang="less">
.Backstage {
  overflow: hidden;
  display: flex;
  .ulnav {
    width: 100%;
    height: 1200px;
    padding: 0;
  }
  .bsLeft {
    width: 15%;
    height: 100%;
    display: inline-block;
    overflow: hidden;
    user-select: none;
    .logo {
      @mainColor: #685454;
      width: 100%;
      height: 70px;
      background-color: @mainColor;
      color: white;
      font-size: 25px;
      overflow: hidden;
      text-align: center;
      line-height: 70px;
    }
    ul {
      list-style: none;
      width: 100%;
      background-color: #ea8a8a;
      li {
        @fontDefaultColor: #000000;
        width: 100%;
        color: @fontDefaultColor;
        height: 45px;
        line-height: 45px;
        cursor: pointer;
        padding: 0 30px;
      }
      .selected {
        background-color: #ebd5d5;
        color: #000000;
      }
    }
  }
  .bsRight {
    width: 85%;
    height: 100%;
    display: inline-block;
    overflow: hidden;
    .header {
      @borderColor: #000000;
      width: 100%;
      height: 70px;
      line-height: 70px;
      border-bottom: 1px solid @borderColor;
      font-size: 18px;
      position: relative;
      user-select: none;
      .title {
        @fontDefaultColor: #000000;
        font-size: 23px;
        position: absolute;
        left: 10px;
        vertical-align: middle;
        color: @fontDefaultColor;
      }
      .userInfo {
        position: absolute;
        right: 10px;
        font-size: 14px;
        span {
          cursor: pointer;
        }
        .userTips {
          @borderColor: #000000;
          position: absolute;
          top: 45px;
          right: 0;
          width: 66px;
          cursor: pointer;
          border: 1px solid @borderColor;
          background-color: white;
          li {
            width: 100%;
            height: 30px;
            text-align: center;
            line-height: 30px;
            border-bottom: 1px solid @borderColor;
          }
        }
      }
    }
  }
}
</style>