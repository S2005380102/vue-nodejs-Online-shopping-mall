<template>
  <div class="GoodsAudit">
    <header class="clear">
      <span>商品审核</span>
      <div>
        <select
          class="filter"
          v-model="filter"
          @change="applyFilterAndResetPage"
        >
          <option value="all">全部</option>
          <option value="pending">待审核</option>
          <option value="approved">审核通过</option>
          <option value="rejected">审核失败</option>
        </select>
      </div>
    </header>
    <div class="content">
      <table class="goodsTable">
        <thead>
          <tr>
            <th>商品ID</th>
            <th>商品名称</th>
            <th>产地</th>
            <th>上架时间</th>
            <th>库存</th>
            <th>价格</th>
            <th>图片</th>
            <th>审核状态</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="(good, index) in paginatedGoods"
            :key="good.id + '-' + index"
          >
            <td>{{ good.id }}</td>
            <td>{{ good.name }}</td>
            <td>{{ good.paddress }}</td>
            <td>{{ new Date(good.ptime).toLocaleString() }}</td>
            <td>{{ good.stock }}</td>
            <td>{{ good.price }}</td>
            <td>
              <img
                :src="good.picture"
                alt="商品图片"
                style="width: 50px; height: 50px"
              />
            </td>
            <td>
              <span v-if="good.type === 0">等待审核</span>
              <span v-else-if="good.type === 1">审核通过</span>
              <span v-else>审核失败</span>
            </td>
            <td>
              <button
                v-if="good.type === 0"
                class="normal approve-btn"
                @click="approveGoods(good.id, 1)"
              >
                通过
              </button>
              <button
                v-if="good.type === 0"
                class="normal disapprove-btn"
                @click="approveGoods(good.id, 2)"
              >
                不通过
              </button>
              <button v-if="good.type !== 0" class="normal result-btn" disabled>
                {{ good.type === 1 ? "审核通过" : "审核失败" }}
              </button>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="pagination">
        <button @click="prevPage" :disabled="currentPage === 1">上一页</button>
        <span>第 {{ currentPage }} 页</span>
        <button @click="nextPage" :disabled="currentPage === totalPages">
          下一页
        </button>
      </div>
    </div>
  </div>
</template>
 
<script>
import axios from "axios";

export default {
  name: "GoodsAudit",
  components: {},
  data() {
    return {
      goodsList: [], // 用于存储从接口获取的商品数据
      paginatedGoods: [], // 用于存储当前页的商品数据
      currentPage: 1, // 当前页码
      pageSize: 10, // 每页显示数量
      totalPages: 0, // 总页数
      filter: "all", // 新增筛选器变量
    };
  },
  methods: {
    async fetchGoods() {
      try {
        const response = await axios.get(
          "http://localhost:8081/my/goods/goods"
        );
        if (response.data.status === 0) {
          this.goodsList = response.data.data;
          this.totalPages = Math.ceil(this.goodsList.length / this.pageSize);
          this.applyFilterAndResetPage(); // 初始化时应用筛选器并重置页码
        } else {
          console.error("获取商品列表失败：", response.data.message);
        }
      } catch (error) {
        console.error("请求失败：", error);
      }
    },
    updatePaginatedGoods() {
      const start = (this.currentPage - 1) * this.pageSize;
      const end = this.currentPage * this.pageSize;
      this.paginatedGoods = this.filteredGoods.slice(start, end);
    },
    prevPage() {
      if (this.currentPage > 1) {
        this.currentPage--;
        this.updatePaginatedGoods();
      }
    },
    nextPage() {
      if (this.currentPage < this.totalPages) {
        this.currentPage++;
        this.updatePaginatedGoods();
      }
    },
    async approveGoods(id, type) {
      try {
        const response = await axios.post(
          "http://localhost:8081/my/goods/approve",
          { id, type }
        );
        if (response.data.status === 0) {
          this.fetchGoods(); // 重新获取数据以更新显示
        } else {
          console.error("审核商品失败：", response.data.message);
        }
      } catch (error) {
        console.error("请求失败：", error);
      }
    },
    applyFilter() {
      if (this.filter === "all") {
        this.filteredGoods = this.goodsList;
      } else if (this.filter === "pending") {
        this.filteredGoods = this.goodsList.filter((good) => good.type === 0);
      } else if (this.filter === "approved") {
        this.filteredGoods = this.goodsList.filter((good) => good.type === 1);
      } else if (this.filter === "rejected") {
        this.filteredGoods = this.goodsList.filter((good) => good.type === 2);
      }
      this.totalPages = Math.ceil(this.filteredGoods.length / this.pageSize); // 更新总页数
      this.updatePaginatedGoods();
    },
    applyFilterAndResetPage() {
      this.applyFilter();
      this.currentPage = 1; // 重置页码到第一页
    },
    setFilter(filter) {
      this.filter = filter;
      this.currentPage = 1; // 重置页码到第一页
      this.applyFilter();
    },
  },
  mounted() {
    this.fetchGoods();
  },
};
</script>

<style scoped lang="less">
.filter {
  margin-left: 15px;
  margin-top: 10px;
}
.pagination {
  display: flex;
  justify-content: center;
  margin-top: 10px;
}
.pagination button {
  margin: 0 5px;
}
.GoodsAudit {
  header {
    width: 100%;
    height: 40px;
    line-height: 40px;
    span {
      float: left;
    }
  }
  .content {
    width: 100%;
    background-color: white;
    position: relative;
    top: -3px;
    padding: 5px;
    .goodsTable {
      width: 100%;
      th {
        text-align: center;
      }

      tbody {
        tr {
          td {
            max-width: 100px;
            min-width: 30px;
            text-align: center;
            .normal {
              display: inline-block;
              padding: 10px 20px;
              font-size: 16px;
              border: none;
              cursor: pointer;
              text-align: center;
              text-decoration: none;
              outline: none;
              font-family: inherit;
              margin: 4px 2px;
              transition: background-color 0.3s, color 0.3s;
              border-radius: 4px; /* 可选：添加圆角 */
            }

            /* 通过按钮样式（绿色） */
            .approve-btn {
              background-color: #4caf50; /* 绿色背景 */
              color: white; /* 白色文字 */
            }

            .approve-btn:hover {
              background-color: #45a049; /* 鼠标悬停时背景颜色变深 */
            }

            /* 不通过按钮样式（红色） */
            .disapprove-btn {
              background-color: #f44336; /* 红色背景 */
              color: white; /* 白色文字 */
            }

            .disapprove-btn:hover {
              background-color: #da190b; /* 鼠标悬停时背景颜色变深 */
            }

            /* 结果按钮样式（禁用状态） */
            .result-btn {
              background-color: #e0e0e0; /* 灰色背景表示禁用 */
              color: #a9a9a9; /* 深灰色文字 */
              cursor: not-allowed; /* 禁用状态下的光标样式 */
            }
          }
        }
      }
    }
  }
}
</style>