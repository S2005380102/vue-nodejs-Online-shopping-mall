// import Vue from 'vue'
import { createStore } from 'vuex';
import admin from './modules/admin'
import {removeInfo } from '@/utils/storage'


const store = createStore({
    //提供数据
    state: {

    },
    //扩展
    getters: {
        aid(state) {
            console.log(state.admin.adminInfo.aid);
            return state.admin.adminInfo.aid
        },
        admin(state) {
            console.log(state.admin.adminInfo.admin);
            return state.admin.adminInfo.admin
        }, 
         token(state) {
            return state.admin.adminInfo.token
        },
    },

    // //修改数方法
    mutations: {

    },
    // //if操作
    actions: {
        clearadmin() {
            removeInfo();
        },
    },
    modules: {
        admin
    },





})
export default store;
