
import {getInfo,setInfo} from '@/utils/storage'
// import axios from 'axios';
export default{
    namespaced:true,
    //提供数据
    state(){
        return{
            adminInfo:getInfo()
        }
    },
    //修改数方法
    mutations:{
        //所有Mutations第一个参数是state
        setadminInfo(state,obj){
            state.adminInfo = obj;  
            setInfo(obj)
         }
    },
}
