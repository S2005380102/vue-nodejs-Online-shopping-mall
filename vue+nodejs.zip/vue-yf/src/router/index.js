
// import { from } from "core-js/core/array"
import { createWebHistory } from "vue-router"
import { createRouter, createWebHashHistory } from "vue-router"

import store from "@/store"


const routes = [
    {
        path: '/',
        component: () => import("@/views/index.vue")
    },
    {
        path: '/index',
        component: () => import("@/views/index.vue")
    },
    {
        path: '/commodity',
        component: () => import("@/views/commodity.vue")
    },
    {
        path: '/news',
        component: () => import("@/views/news.vue")
    },
    {
        path: '/news_Detail',
        component: () => import("@/views/news_Detail.vue")
    },
    {
        path: '/news',
        component: () => import("@/views/newproduct.vue")
    },
    {
        path: '/serve',
        component: () => import("@/views/serve.vue")
    },
    {
        path: '/newproduct',
        component: () => import("@/views/newproduct.vue")
    },
    {
        path: '/link',
        component: () => import("@/views/link.vue")
    },
    {
        path: '/login',
        component: () => import("@/views/login.vue")
    },
    {
        path: '/register',
        component: () => import("@/views/register.vue")
    },
    {
        path: '/cart',
        component: () => import("@/views/cart.vue")
    },
    {
        path: '/commodity_Detail',
        component: () => import("@/views/commodity_Detail.vue")
    },
    {
        name: 'order',
        path: '/order',
        component: () => import("@/views/order.vue")
    },
    {
        name: 'myorder',
        path: '/myorder',
        component: () => import("@/views/myorder.vue")
    },
    {
        name: 'UserAvatar',
        path: '/User_Avatar',
        component: () => import("@/views/UserAvatar.vue")
    }, 
    {
        name: 'UserProfile',
        path: '/User_Profile',
        component: () => import("@/views/UserProfile.vue")
    },
    {
        name: 'UserPassword',
        path: '/User_Password',
        component: () => import("@/views/UserPassword.vue")
    }, 
    {
        name: 'User_Address',
        path: '/User_Address',
        component: () => import("@/views/User_Address.vue")
    }, 
    {
        name: 'User_Address',
        path: '/User_Address',
        component: () => import("@/views/User_Address.vue")
    }, 
]

const router = createRouter({
    history: createWebHistory(),
    routes
})






//导航守卫
//to 去哪
//from 哪里来
//放行？

const authUrls = ['/pay', '/order', '/cart']


router.beforeEach((to, from, next) => {

    // console.log(to,from,next)
    //非权限页面放行
    if (!authUrls.includes(to.path)) {
        next();
        return

    }
    //权限页面，需要token
    const token = store.getters.token
    if (token) {
        next()
    } else {
        alert("请先登录");
        console.log(token)
        next('/login')
    }

    console.log(token)

    
})









export default router







// 3写法

// import app from '@/views/App'


// import Vue from 'vue'
// import VueRouter from 'vue-router'

// Vue.use(VueRouter)
// const router = new VueRouter({

//     routes: [
//         {
//             path: '/views/App',
//             component: app
//         },
//         {
//             path: '/views',
//             redirect: '/App'　　//默认显示
//         }
//     ]



// })



