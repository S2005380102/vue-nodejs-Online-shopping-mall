<template>
    <div>
      <top></top>
      <navv></navv>
      <mk1></mk1>
      <mk2></mk2>
    </div>
  </template>
  
  <script>
  import navv from "@/components/nav.vue";
  import top from "@/components/top.vue";
  import mk1 from "@/components/mk1.vue";
  import mk2 from "@/components/mk2.vue";
  export default {
    name: "App",
    components: {
      mk1,
      mk2,
      navv,
      top
    },
    
  };



  </script>
  
  
  <style scoped>
  body {
    margin: 0;
    background: #f3f3f3;
  }
  </style>
  
  
  
  