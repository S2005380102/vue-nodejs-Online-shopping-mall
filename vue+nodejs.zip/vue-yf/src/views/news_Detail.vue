<template>
      <top></top>
      <navv></navv>
    <div class="news-detail-page">
      <header class="news-header">
        <h1>{{ newsItem.title }}</h1>
        <div class="news-meta">
          <span>发布时间: {{ formatDate(newsItem.publishedAt) }}</span>
          <span>作者: {{ newsItem.author }}</span>
        </div>
      </header>
      <article class="news-content">
        <p v-html="newsItem.content"></p>
      </article>
      <footer class="news-footer">
        <button @click="goBack">返回上一页</button>
      </footer>
    </div>
  </template>
   
  <script>
  import axios from "axios";
  import navv from "@/components/nav.vue";
  import top from "@/components/top.vue";
  export default {
    name: "NewsDetailPage",
    components: {
      navv,
      top
    },
    data() {
      return {
        newsItem: {},
      };
    },
    created() {
      this.fetchNewsDetail();
    },
    methods: {
      async fetchNewsDetail() {
        try {
          var id = this.$route.query.id;
          const response = await axios.get(`http://localhost:8081/api/news/` + id);
          const newsData = response.data.data[0];
          this.newsItem = {
            ...newsData,
            publishedAt: newsData.time,
          };
        } catch (error) {
          console.error("获取新闻详情失败:", error);
        }
      },
      formatDate(dateString) {
        const date = new Date(dateString);
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}:${String(date.getSeconds()).padStart(2, "0")}`;
      },
      goBack() {
        window.history.back();
      },
    },
  };
  </script>
  
  <style scoped>
  .news-detail-page {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    font-family: Arial, sans-serif;
  }
   
  .news-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap:wrap;
    margin-bottom: 20px;
  }
   
  .news-header h1 {
    margin: 0;
    font-size: 2.5em;
  }
   
  .news-meta {
  margin-top: 5px;
  color: #666;
}
 
.news-meta span {
  display: block; 
  margin-bottom: 5px; 
}
   

   
  .news-content p {
    line-height: 1.6;
    color: #333;
  }
   
  .news-footer {
    margin-top: 20px;
    text-align: right;
  }
   
  .news-footer button {
    padding: 10px 20px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }
   
  .news-footer button:hover {
    background-color: #0056b3;
  }
  </style>