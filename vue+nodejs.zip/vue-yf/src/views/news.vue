<template>
  <top></top>
  <navv></navv>
  <div class="news-list-page">
    <header class="news-header">
      <h1>新闻公告列表</h1>
    </header>
    <div class="news-items">
      <div
        v-for="(item, index) in paginatedNews"
        :key="item.id"
        class="news-item"
      >
        <h2 class="title" @click="goToNews(item.id)">{{ item.title }}</h2>
        <p>{{ item.summary }}</p>
        <div class="news-meta">
          <span>发布时间: {{ item.formattedTime }}</span>
        </div>
      </div>
    </div>
    <footer class="news-pagination">
      <button
        v-if="currentPage > 1"
        @click="prevPage"
        class="pagination-button"
      >
        上一页
      </button>
      <span class="pagination-info">
        第 {{ currentPage }} 页 / 共 {{ totalPages }} 页
      </span>
      <button
        v-if="currentPage < totalPages"
        @click="nextPage"
        class="pagination-button"
      >
        下一页
      </button>
    </footer>
  </div>
</template>

<script>
import axios from "axios";
import navv from "@/components/nav.vue";
import top from "@/components/top.vue";
export default {
  name: "NewsListPage",
  components: {
    navv,
    top,
  },
  data() {
    return {
      articles: [],
      itemsPerPage: 5, // 每页显示的新闻数量
      currentPage: 1, // 当前页码
    };
  },
  computed: {
    paginatedNews() {
      const start = (this.currentPage - 1) * this.itemsPerPage;
      const end = start + this.itemsPerPage;
      return this.articles.slice(start, end);
    },
    totalPages() {
      return Math.ceil(this.articles.length / this.itemsPerPage);
    },
    formattedArticles() {
      return this.articles.map((article) => ({
        ...article,
        formattedTime: this.formatDate(article.time), // 使用辅助函数格式化日期
      }));
    },
  },
  methods: {
    async fetchNews() {
      try {
        const response = await axios.get("http://localhost:8081/api/newslist");
        // 假设后端返回的数据结构为 { data: [...] }，其中data是新闻列表数组
        const newsList = response.data.data;

        // 更新articles数据，并立即格式化时间
        this.articles = newsList.map((article) => ({
          ...article,
          formattedTime: this.formatDate(article.time),
        }));
      } catch (error) {
        console.error("获取新闻列表失败:", error);
        // 可以在这里处理错误，比如显示错误消息
      }
    },
    formatDate(dateStr) {
      const date = new Date(dateStr);
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, "0"); // 月份从0开始，需要加1
      const day = String(date.getDate()).padStart(2, "0");
      return `${year}/${month}/${day}`;
    },
    prevPage() {
      if (this.currentPage > 1) {
        this.currentPage--;
      }
    },
    nextPage() {
      if (this.currentPage < this.totalPages) {
        this.currentPage++;
      }
    },
    goToNews(id) {
      this.$router.push(`/news_Detail?id=${id}`);
    },
  },
  mounted() {
    this.fetchNews();
  },
};
</script>

<style scoped>
.news-list-page {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  font-family: Arial, sans-serif;
}

.news-header {
  text-align: center;
  margin-bottom: 20px;
}

.news-header h1 {
  margin: 0;
  font-size: 2em;
}

.news-items {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.news-item {
  background-color: #f9f9f9;
  padding: 15px;
  border-radius: 5px;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
}

.news-item h2 {
  margin: 0 0 10px;
  font-size: 1.5em;
}

.news-item p {
  margin: 0;
  color: #333;
}

.news-meta {
  margin-top: 10px;
  color: #666;
  font-size: 0.9em;
}

.news-pagination {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;
}

.pagination-button {
  padding: 10px 20px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.pagination-button:hover {
  background-color: #0056b3;
}

.pagination-info {
  font-size: 0.9em;
  color: #666;
}
.title {
  font-size: 18px;
}
.title:hover {
  cursor: pointer;
  color: #0faa9c;
}
</style>