<script>
import axios from "axios";
import { mapGetters, mapActions } from "vuex";
import User_Sidebar from "@/components/User_Sidebar.vue";
import navv from "@/components/nav.vue";
import top from "@/components/top.vue";

export default {
  components: {
    User_Sidebar,
    navv,
    top,
  },
  data() {
    return {
      form: {
        id:this.uid,
        username: "", // 这个值将从 Vuex 中获取，并且是只读的
        email: "",
      },
      userInfo: null, // 用于存储从后端获取的用户信息
    };
  },
  computed: {
    ...mapGetters({
      uid: "uid", // 假设 Vuex store 中有一个 user 模块，它有一个 uid getter
      usernameFromStore: "userid", // 假设 Vuex store 中还有一个用户名
    }),
  },
  methods: {
    ...mapActions([
      "user/updateUserInfo", // 映射 Vuex action 用于更新用户信息
    ]),
    async fetchUserInfo() {
      try {
        const response = await axios.get(
          `http://localhost:8081/my/userinfo?id=${this.uid}`
        );
        this.userInfo = response.data.data;
        // 设置表单中的邮箱地址
        this.form.email = this.userInfo.email; // 假设后端返回的数据中包含 email 字段
      } catch (error) {
        console.error("Failed to fetch user info:", error);
        // 显示错误消息（这里需要您有一个显示错误消息的机制）
      }
    },
    submitForm() {
      if (!this.form.email) {
        this.message = "请填写邮箱地址。";
        return;
      }
;
      // 使用axios发送POST请求
      const formData = { ...this.form, id: this.uid };
      console.log( this.form)
      axios
        .post("http://localhost:8081/my/userinfo", formData)
        .then((response) => {
          // 根据服务器响应设置消息
          if (response.data.status==0) {
            this.message = "更新成功！";
          } else {
            this.message = "更新失败：" + response.data.message;
          }
          // 可以在这里重置表单或执行其他操作
        })
        .catch((error) => {
          // 处理请求错误
          this.message = "提交失败，请稍后重试。";
          console.error(error);
        });
    },
  },
  mounted() {
    // 组件挂载后，从 Vuex store 中获取用户名，并尝试从后端获取用户信息
    this.form.username = this.usernameFromStore; // 设置表单中的用户名（只读）
    this.fetchUserInfo();
  },
  watch: {
    // 如果 Vuex store 中的 uid 发生变化（尽管在这个场景中可能不常见），则重新获取用户信息
    uid(newVal) {
      if (newVal) {
        this.fetchUserInfo();
      }
    },
  },
};
</script>

<template>
  <div>
    <top></top>
    <navv></navv>
    <div class="container">
      <User_Sidebar />
      <div class="main-content">
        <div class="page-container">
          <h2>基本资料</h2>
          <!-- 表单部分 -->
          <form @submit.prevent="submitForm">
            <div>
              <label for="username">用户昵称:</label>
              <input
                type="text"
                id="username"
                v-model="form.username"
                disabled
              />
            </div>
            <div>
              <label for="email">用户邮箱:</label>
              <input type="email" id="email" v-model="form.email" />
            </div>
            <div>
              <button type="submit">提交修改</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>



<style scoped>
.page-container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 5px;
}

.page-container h2 {
  text-align: center;
}

.page-container div {
  margin-bottom: 15px;
}

.page-container label {
  display: inline-block;
  width: 100px;
  vertical-align: top;
}

.page-container input {
  width: calc(100% - 120px); /* 100px label width + some padding */
  padding: 8px;
  box-sizing: border-box;
}

.page-container button {
  display: block;
  width: 100%;
  padding: 10px;
  background-color: #409eff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.page-container button:hover {
  background-color: #66b1ff;
}
.container {
  /* display: flex; */
}

.main-content {
  flex: 1;
  /* 其他样式 */
}
</style>