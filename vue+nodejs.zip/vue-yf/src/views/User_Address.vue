<template>
  <div>
    <top></top>
    <navv></navv>
    <User_Sidebar />
    <div class="upload-avatar">
      <h2>收货地址管理</h2>
      <button @click="showAddAddressForm = true">
        添加收货地址
      </button>
      <div v-if="showAddAddressForm" class="AddressItem-add-form-overlay">
        <div class="AddressItem-add-form-container">
          <form @submit.prevent="addAddress($event)">
            <!-- 表单内容 -->
            <div>
              <label>姓名:</label>
              <input type="text" v-model="newAddressForm.name" required />
            </div>
            <div>
              <label>电话:</label>
              <input type="text" v-model="newAddressForm.phone" required />
            </div>
            <div>
              <label>省份:</label>
              <input type="text" v-model="newAddressForm.province" required />
            </div>
            <div>
              <label>城市:</label>
              <input type="text" v-model="newAddressForm.city" required />
            </div>
            <div>
              <label>详细地址:</label>
              <input type="text" v-model="newAddressForm.address" required />
            </div>
            <div>
              <label>邮政编码:</label>
              <input type="text" v-model="newAddressForm.postalCode" required />
            </div>

            <button type="submit" style="margin-top: 10px;">保存</button>
            <button type="button" style="margin-top: 10px;" @click="showAddAddressForm = false">
              取消
            </button>
          </form>
        </div>
      </div>
      <AddressBook />
    </div>
  </div>
</template>
   
  <script>
import axios from "axios";
import User_Sidebar from "@/components/User_Sidebar.vue";
import navv from "@/components/nav.vue";
import top from "@/components/top.vue";
import AddressBook from "@/components/AddressBook.vue";
export default {
  components: {
    User_Sidebar,
    navv,
    top,
    AddressBook,
  },
  data() {
    return {
      newAddressForm: {
        uid:this.$store.getters.uid,
        name: "",
        phone: "",
        province: "",
        city: "",
        address: "",
        postalCode: "",
      },
      showAddAddressForm: false, // 控制添加地址表单的显示和隐藏
    };
  },
  methods: {
    addAddress(event) {
      // 在这里添加验证逻辑（如果需要）
      axios
        .post("http://localhost:8081/api/AddAddress", this.newAddressForm)
        .then((response) => {
          // 假设服务器返回了新地址对象
          const newAddress = response.data;
          // 更新本地状态（如果需要）
          // 例如，如果您没有在本地维护地址列表，这一步可以省略
          // this.addresses.push(newAddress);

          // 重置表单
          this.newAddressForm = {
            name: "",
            phone: "",
            province: "",
            city: "",
            address: "",
            postalCode: "",
          };

          // 隐藏表单
          this.showAddAddressForm = false;

          // 显示成功消息（如果需要）
          alert("地址添加成功！");
        })
        .catch((error) => {
          // 显示错误消息
          console.error("添加地址失败:", error);
          alert("添加地址失败，请稍后再试。");
        });
    },
  },
};
</script>
    
    <style scoped>
.upload-avatar {
  max-width: 70%;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.upload-avatar label {
  display: block;
  margin-bottom: 5px;
}

.upload-avatar input[type="file"] {
  width: 100%;
  padding: 8px;
  margin-bottom: 15px;
  box-sizing: border-box;
}

.upload-avatar button {
  width: 100%;
  padding: 10px;
  background-color: #42b983;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.upload-avatar button:hover {
  background-color: #369472;
}

.upload-avatar p {
  color: red;
}

.add-address-button {
  position: absolute;
  top: 10px; /* 根据需要调整 */
  right: 10px; /* 根据需要调整 */
}

.AddressItem-add-form-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 999;
}

.AddressItem-add-form-container {
  background: white;
  padding: 20px;
  border-radius: 5px;
}
</style>