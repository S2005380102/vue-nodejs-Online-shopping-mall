<template>
  <div>
    <top></top>
    <navv></navv>
    <User_Sidebar />
    <div class="reset-password">
      <h2>重置密码</h2>
      <form @submit.prevent="submitForm">
        <div>
          <label for="userId">用户名:</label>
          <input type="text" id="userId" v-model="form.username" disabled />
        </div>
        <div>
          <label for="oldPwd">旧密码:</label>
          <input type="password" id="oldPwd" v-model="form.oldPwd" required />
        </div>
        <div>
          <label for="newPwd">新密码:</label>
          <input type="password" id="newPwd" v-model="form.newPwd" required />
        </div>
        <button type="submit">重置密码</button>
      </form>
    </div>
  </div>
</template>
  

  <script>
import axios from "axios";
import User_Sidebar from "@/components/User_Sidebar.vue";
import navv from "@/components/nav.vue";
import top from "@/components/top.vue";
export default {
  components: {
    User_Sidebar,
    navv,
    top,
  },
  data() {
    return {
      form: {
        id: this.$store.getters.uid,
        username: this.$store.getters.userid,
        oldPwd: "",
        newPwd: "",
      },
      message: "",
    };
  },
  methods: {
    submitForm() {
      // 发送POST请求到后端接口
      axios
        .post("http://localhost:8081/my/updatepwd", this.form)
        .then((response) => {
          // 根据服务器响应设置消息
          if (response.data.success) {
            this.message = "密码重置成功！";
            // 可以选择在这里清空表单
            this.form.oldPwd = "";
            this.form.newPwd = "";
          } else {
            this.message = "密码重置失败：" + response.data.message;
          }
        })
        .catch((error) => {
          // 处理请求错误
          this.message = "提交失败，请稍后重试。";
          console.error(error);
        });
    },
  },
};
</script>
  
  <style scoped>
.reset-password {
  
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.reset-password label {
  display: block;
  margin-bottom: 5px;
}

.reset-password input {
  width: 100%;
  padding: 8px;
  margin-bottom: 15px;
  box-sizing: border-box;
}

.reset-password button {
  width: 100%;
  padding: 10px;
  background-color: #42b983;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.reset-password button:hover {
  background-color: #369472;
}

.reset-password p {
  color: red;
}
</style>