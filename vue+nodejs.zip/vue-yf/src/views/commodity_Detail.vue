<template>
  <div>
    <top></top>
    <navv></navv>
    <div class="zt">
      <div>
        <!-- <img v-if="teas.picture" :src="teas.picture" alt="" class="img" /> -->

        <img class="spt" :src="products.picture" alt="" />
      </div>
      <div class="xzt">
        <div>
          <p class="bt1">{{ products.name }}</p>
        </div>
        <hr />
        <div class="dj">
          <div class="dj1">
            <div class="bq">市场价</div>
            <div class="jiaqian">
              <div class="yuan">￥</div>
              <div class="jiage">{{ products.price }}.00</div>
            </div>
          </div>
          <div class="dj1">
            <div class="bq2">促销</div>
            <div>
              <div class="cx">
                <div class="icon-text">包邮</div>
                <div class="tips-text">全场免运费</div>
              </div>
              <div class="cx">
                <div class="icon-text">直降</div>
                <div class="tips-text">已优惠0元</div>
              </div>
            </div>
          </div>
        </div>
        <hr />
        <div>
          {{ carts }}
          <span class="bq">产地</span
          ><span class="bq1">{{ products.paddress }}</span>
          <span class="bq">净含量</span><span class="bq1">250克</span>
          <span class="bq">商品编号</span
          ><span class="bq1">{{ products.id }}</span>
        </div>
        <hr />
        <div style="display: flex; align-items: center">
          <div class="bq">
            数量
            <button type="button" class="jian" @click="jian(index)">-</button>
            <input
              type="number"
              v-model.number="quantity"
              @input="updateQuantity"
              pattern="\d*"
              class="sl"
              readonly
            />
            <button type="button" class="jia" @click="jia(index)">+</button>
          </div>
        </div>
        <hr />
        <div>
          <div class="jr-cart" @click="addCart(products.id, quantity)">
            加入购物车
          </div>
        </div>
        <hr />
        <div class="g-fw">
          <ul>
            <li>服务</li>
            <li>90天商品保价</li>
            <li>30天无理由退货</li>
            <li>10分钟极速退款</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Dialog } from "vant";
import axios from "axios";
import navv from "@/components/nav.vue";
import top from "@/components/top.vue";

export default {
  components: {
    navv,
    top,
  },
  data() {
    return {
      products: [], // 用于存储商品列表的数据
      quantity: 1,
    };
  },
  created() {
    const id = this.$route.query.id;
    console.log(id);
    this.fetchProducts();
  },
  methods: {
    async fetchProducts() {
      try {
        var id = this.$route.query.id;
        const response = await axios.get(
          "http://localhost:8081/my/goods/detail?id=" + id
        );
        this.products = response.data.data;
        console.log(this.products);
      } catch (error) {
        console.error("获取商品失败:", error);
      }
    },

    jia() {
      this.quantity++;
    },
    jian() {
      if (this.quantity > 1) {
        this.quantity--;
      }
    },

    updateQuantity(event) {
      // 获取输入框的值
      const inputValue = event.target.value;
      // 尝试将输入值转换为数字
      let newQuantity = parseInt(inputValue, 10);
      // 如果转换失败或数量小于1，则使用默认值（这里假设是1）
      if (isNaN(newQuantity) || newQuantity < 1) {
        newQuantity = 1;
      }
      // 更新商品的数量（现在需要将其转换回字符串，因为输入框期望的是字符串）
      this.quantity = newQuantity.toString();
    },

    addCart(id, quantity) {
      if (!this.$store.getters.token) {
        console.log("确认");
        Dialog.confirm({
          title: "温馨提示",
          message: "需要登录",
          confirmButtonText: "去登陆",
          cancelButtonText: "再逛逛",
        })
          .then(() => {
            this.$router.push("/login");
          })
          .catch(() => {});
        return;
      } else {
        // this.$store.dispatch("cart/updateCartItem", {index, num: this.tableData[index].num,});
        var uid = this.$store.getters.uid;
        this.$store.commit("cart/addCart", { id, quantity, uid });

        console.log(this.$store.getters.uid);

        // // 使用 axios 发送 POST 请求
        // axios
        //   .post("http://localhost:8081/api/addcart", {
        //     uid: uid,
        //     good_id: id,
        //     good_name: this.products.name,
        //     good_price: this.products.price,
        //     good_num: quantity,
        //     good_img: this.products.picture,
        //   })
        //   .then((response) => {

        //     if (response.data.status === 0) {
        //       // 根据你的API响应状态码来判断成功
        //       // 处理响应数据，例如更新 UI 或显示消息
        //       console.log("添加购物车成功");
        //       this.$store.dispatch('clearCart')
        //     } else {
        //       // 处理错误响应
        //       console.error("添加购物车失败", response.statusText);
        //     }
        //   })
        //   .catch((error) => {
        //     // 处理网络错误或其他错误
        //     console.error("Error:", error);
        //   });
      }
      //  console.log('正常')
      // console.log(this.$store.state.cart.carts)
      // console.log(this.$store.getters['cart/carts'])
    },

    // addcart() {
    //   if (!this.$store.getters.token) {
    //     // console.log('确认');
    //     // 使用 Dialog.confirm 显示确认对话框
    //     Dialog.confirm({
    //       title: '温馨提示',
    //       message: '需要登录'
    //     })
    //     .then(() => {
    //       // 用户点击确认后跳转到登录页面
    //       this.$router.push('/login');
    //     })
    //     .catch(() => {
    //       // 用户点击取消或其他错误处理
    //     });
    //     return; // 阻止后续代码执行
    //   }
    //   console.log('正常'); // 注意：这个 log 应该在 if 语句之外，否则它永远不会执行（如果 token 存在）
    // }
  },
};
</script>





<style>
.zt {
  display: flex;
  flex-direction: row;
  width: 950px;
  justify-content: space-around;
  margin: 25px auto;
  font-size: 14px;
}

.spt {
  font-size: 14px;
  color: #333;
  list-style: none;
  margin: 0;
  padding: 0;
  display: block;
  width: 482px;
  height: 482px;
  position: relative;
}

.jian {
  width: 20px;
  height: 30px;
  margin-left: 46px;
}
.jia {
  width: 20px;
  height: 30px;
}

.jr-cart {
  margin: 0;
  padding: 0;
  cursor: pointer;
  width: 266px;
  text-align: center;
  line-height: 50px;
  font-size: 16px;
  /* background-image: url('../images/addcart.png'); */
  background-repeat: no-repeat;
  background-position: 60px center;
  -webkit-transition: all 0.2s;
  color: #fff;
  background-color: #f03400;
}
.zt p {
  /* line-height: 250px; */
}
.zt .bt1 {
  font-size: 20px;
  color: #000;
  margin-bottom: 16px;
  font-weight: bold;
}
.zt .bq {
  margin-top: 10px;
  margin-right: 35px;
  color: #ccc;
}
.zt .bq1 {
  margin-right: 20px;
}
.dj {
  display: flex;
  flex-direction: column;
}
.dj1 {
  margin: 5px 0 5px 0;
  display: flex;
  flex-direction: row;
}
.sl {
  width: 44px;
  height: 26px;
  text-align: center;
  line-height: 26px;
  text-indent: 0;
  position: relative;
  top: 1px;
}

.cx {
  margin-top: 10px;
  display: flex;
  flex-direction: row;
}

.icon-text {
  font-size: 14px;

  padding: 0;
  width: 36px;
  height: 20px;
  border: 1px solid red;
  background-color: #fff;
  color: #ff3600;
  text-align: center;
  line-height: 20px;
  margin-right: 5px;
}
.tips-text {
  margin: 0;
  padding: 0;
  width: 430px;
  line-height: 20px;
  font-size: 12px;
  color: #333;
}
.xzt {
  margin: 0 0 0 50px;
}
hr {
  margin: 15px 0 20px 0;
}

.g-fw {
  margin: 0;
  padding: 0;
  color: #ccc;
  font-size: 12px;
  float: left;
}
.g-fw ul {
  font-family: "微软雅黑";
  color: #ccc;
  font-size: 12px;
  margin: 0;
  padding: 0;
  list-style: none;
}
.g-fw ul li {
  float: left;
  margin-right: 20px;
}
.bq2 {
  color: #ccc;
  width: 80px;
  margin-top: 10px;
}
.yuan {
  float: left;
  font-size: 14px;
  margin-top: 9px;
  color: #b60005;
}
.jiage {
  float: left;
  color: #b60005;
  margin-left: 0;
  font-size: 24px;
  font-weight: bold;
}
.jiaqian {
  width: 200px;
}
</style>