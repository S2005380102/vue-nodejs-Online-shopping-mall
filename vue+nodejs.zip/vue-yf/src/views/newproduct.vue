<template>
  
</template>

<script>
 import navv from "@/components/nav.vue";
  import top from "@/components/top.vue";
export default {
    components: {
      navv,
      top
    },
}
</script>

<style>

</style>