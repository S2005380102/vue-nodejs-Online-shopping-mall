<template>
  <div>
    <top></top>
    <navv></navv>
    <goods></goods>
  </div>
</template>

<script>
import goods from "@/components/commodity/goods.vue";
import navv from "@/components/nav.vue";
import top from "@/components/top.vue";
export default {
  components: {
    navv,
    top,
    goods,
  },
};
</script>

<style>
</style>