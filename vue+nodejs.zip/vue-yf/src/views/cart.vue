<template>
  <div>
    <top></top>
    <navv></navv>

    <table class="cart">
      <!-- <thead> -->
      <tr class="btou">
        <td class="qx">
          <input
            type="checkbox"
            class="checkbox"
            v-model="allChecked"
            @change="AllSelection"
          />全选
        </td>
        <td class="spn">名称</td>
        <td class="jiage">价格</td>
        <td class="suliang">数量</td>
        <td class="xiaoji">小计</td>
        <td class="caozuo">操作</td>
      </tr>
      <!-- </thead>
    <tbody> -->
      <tr class="cartlist" v-for="(goods, index) in tableData" :key="index">
        <td class="qx">
          <input
            type="checkbox"
            class="checkbox"
            @change="calculateTotalPrice"
            v-model="goods.isSelected"
          />
        </td>
        <td class="spn">
          <img
            v-if="goods.good_img"
            :src="goods.good_img"
            alt=""
            class="sptu"
          />{{ goods.good_name }}
        </td>
        <td class="jiage">{{ goods.good_price }}</td>
        <td class="suliang">
          <div class="cartbq">
            <button type="button" class="jian" @click="decreaseQuantity(index)">
              -
            </button>
            <!-- <input type="text" :value="goods.num" class="sl" /> -->
            <input
              type="number"
              v-model.number="goods.good_num"
              @input="validateQuantity(index, $event.target.value)"
              id="number-input"
              class="sl"
            />
            <button type="button" class="jia" @click="increaseQuantity(index)">
              +
            </button>
          </div>
        </td>
        <td class="xiaoji">￥{{ goods.good_price * goods.good_num }}</td>

        <td class="caozuo">
          <a href="#" @click="deleteCart(goods.good_id)">删除</a>
        </td>
      </tr>
      <!-- </tbody> -->
      <div class="cart-sum clearfix">
        <span class="sum-money float-right" @click="submitOrder()">去结算</span>
        <div class="all-money">
          <span
            ><span class="label-txt"
              ><span class="isoffer">总价</span>（不含运费）：</span
            ><span class="red_money"
              >￥<span class="big-money">{{ totalPrice }}</span></span
            ></span
          >
        </div>
      </div>
    </table>
  </div>
</template>

<script>
import navv from "@/components/nav.vue";
import top from "@/components/top.vue";
import store from "@/store";
export default {
  name: "App",
  data() {
    return {
      tableData: this.$store.getters.cart.map((good) => ({
        ...good,
        isSelected: false, // 假设 Vuex store 没有提供这个属性
      })),
      allChecked: false,
      totalPrice: 0, // 新增属性，用于存储总价
    };
  },
  components: {
    top,
    navv,
  },
  mounted() {
    // const id = store.getters.id
    // console.log(this.$store.getters.token)
    // console.log(this.$store.getters.id)
    console.log(this.$store.getters.cart);
    // console.log(this.$store.state.cart.carts)
    // console.log(this.$store.getters['cart/carts'])
  },
  methods: {
    //订单处理
    submitOrder() {
      this.storeSelectedGoodsInCache();
      // 检查存储后的商品是否为空，并做出相应处理
      const order = JSON.parse(localStorage.getItem("order"));
      if (order && order.length > 0) {
        // 如果商品不为空，则跳转到订单结算页面
        this.$router.push({ name: "order" }); // 假设你的订单结算页面路由名为 'orderSettlement'
      } else {
        // 如果商品为空，则弹出提示框
        alert("请选择商品", "提示", {
          confirmButtonText: "确定",
        });
        // 注意：这里使用的 $alert 可能需要安装一个第三方库，如 Vue Sweetalert2，或者你可以使用原生的 alert 方法
        // alert('请选择商品');
      }
    },
    getSelectedGoods() {
      return this.tableData.filter((goods) => goods.isSelected);
    },
    storeSelectedGoodsInCache() {
      const order = this.getSelectedGoods();
      console.log(order);
      localStorage.setItem("order", JSON.stringify(order)); // 不需要先 removeItem，直接 setItem 会覆盖旧值
      // 注意：这里不再调用 removeItem，因为 setItem 会自动覆盖同名项
    },

    calculateTotalPrice() {
      let total = 0;
      let allSelected = this.tableData.every((goods) => goods.isSelected); // 检查所有商品是否都被选中

      this.tableData.forEach((goods) => {
        if (goods.isSelected) {
          total += goods.good_price * goods.good_num;
        }
      });

      this.totalPrice = total.toFixed(2);
      this.allChecked = allSelected; // 直接根据所有商品的实际选中状态来设置 allChecked
    },

    // 更新全选复选框的逻辑
    AllSelection(event) {
      this.allChecked = event.target.checked;
      this.tableData.forEach((goods) => {
        goods.isSelected = this.allChecked;
      });
      this.calculateTotalPrice(); // 在全选状态改变时计算总价并检查所有商品是否都被选中
    },

    increaseQuantity(index) {
      if (this.tableData[index].good_num < Number.MAX_SAFE_INTEGER) {
        // 防止数量溢出
        this.tableData[index].good_num++;
      }
      // 更新Vuex store中购物车状态的代码
      this.$store.dispatch("cart/updateCartItem", {
        index,
        num: this.tableData[index].good_num,
      });
      this.calculateTotalPrice();
    },
    decreaseQuantity(index) {
      if (this.tableData[index].good_num > 1) {
        // 数量不能小于1
        this.tableData[index].good_num--;
      }
      // 更新Vuex store中购物车状态的代码
      this.$store.dispatch("cart/updateCartItem", {
        index,
        num: this.tableData[index].good_num,
      });
      this.calculateTotalPrice();
    },

    validateQuantity(index, value) {
      const num = parseInt(value, 10);
      if (!isNaN(num) && num >= 1 && num <= Number.MAX_SAFE_INTEGER) {
        this.tableData[index].good_num = num;
        // 更新Vuex store中的状态
        this.$store.dispatch("cart/updateCartItem", {
          index,
          num: this.tableData[index].good_num,
        });
      } else {
        // 恢复到之前的合法值，或者设置为默认值（如1）
        this.tableData[index].good_num = Math.max(
          1,
          this.tableData[index].good_num
        );
      }
    },

    calculateSubtotal(goods) {
      // 计算单项小计，这里假设价格是字符串，需要转换为数字进行计算
      return (parseFloat(goods.price) * parseInt(goods.num)).toFixed(2);
    },

    deleteCart(id) {
      console.log(id);
      this.$store.commit("cart/delCart", { id });
      location.reload(true);
    },
  },



  
  watch: {
    // 监听路由query中的refresh参数
    "$route.query.refresh": {
      immediate: true, // 立即执行一次handler
      handler(val) {
        if (val) {
          this.list(); // 调用组件的list方法，通常用于重新加载数据
        }
      },
    },
  },
};
</script>

<style scoped>
#number-input::-webkit-inner-spin-button,
#number-input::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* 兼容Firefox */
#number-input[type="number"] {
  -moz-appearance: textfield;
}

.cart {
  width: 1200px;
  margin: 0 auto;
  padding: 0;
}

.cart td {
  padding-top: 26px;
  padding-bottom: 26px;
}

.btou {
  width: 1200px;
  display: flex;
  flex-direction: row;
  justify-content: space-around;
}

.cartlist {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
}
.cartbq {
  width: 120px;
  display: flex;
  flex-direction: row;
  margin: 0 auto;
}
.jian,
.jia {
  width: 20px;
  /* height: 30px; */
  padding: 0 5px 0 5px;
}
.sl {
  width: 42px;
  height: 28px;
  text-align: center;
}
.sptu {
  float: left;
  width: 70px;
  height: 70px;
}

.checkbox {
  width: 20px;
  height: 20px;
}

.cart-sum {
  font-family: Arial, Tahoma, "Microsoft YaHei", "微软雅黑", "Helvetica Neue",
    Helvetica, STHeiTi, sans-serif;
  font-size: 14px;
  color: #333;
  padding: 0;
  box-shadow: 0px -2px 3px rgba(0, 0, 0, 0.2);
  width: 1226px;
  z-index: 100;
  height: 72px;
  margin: 30px 0 60px;
  background-color: #fff;
  position: relative;
}

.sum-money {
  font-family: Arial, Tahoma, "Microsoft YaHei", "微软雅黑", "Helvetica Neue",
    Helvetica, STHeiTi, sans-serif;
  float: right;
  width: 200px;
  cursor: pointer;
  font-size: 18px;
  text-align: center;
  line-height: 72px;
  height: 72px;
  -webkit-transition: all 0.2s;
  background-color: #f03400;
  color: #fff;
}

.all-money {
  font-family: Arial, Tahoma, "Microsoft YaHei", "微软雅黑", "Helvetica Neue",
    Helvetica, STHeiTi, sans-serif;
  font-size: 14px;
  margin: 0;
  padding: 0;
  color: #333;
  float: right;
  margin-right: 40px;
  padding-top: 23px;
  position: relative;
}
.label-txt {
  display: inline-block;
  width: 140px;
  text-align: right;
  color: #424242;
  font-size: 14px;
}
.red_money {
  margin-left: 10px;
  color: #c00000;
  font-size: 14px;
}
.big-money {
  font-size: 26px;
  font-weight: bold;
  color: #c00000;
}
.isoffer {
  text-align: right;
  color: #424242;
  font-size: 14px;
}
</style>