<template>
  <div>
    <top></top>
    <navv></navv>
    <div class="order-list">
      <table class="cart">
        <tr class="btou">
          <td class="spn">订单号</td>
          <td class="jiage">订单日期</td>
          <td class="suliang">总价</td>
          <td class="xiaoji">状态</td>
          <td class="goods">商品信息</td>
          <!-- 新增商品信息列 -->
        </tr>
        <tr
          v-for="(order, index) in orders"
          :key="order.order_id"
          class="cartlist"
        >
          <td class="spn">{{ order.order_id }}</td>
          <td class="jiage">{{ formatDate(order.Addtime) }}</td>
          <td class="suliang">￥{{ order.money.toFixed(2) }}</td>
          <td class="xiaoji">
            <div
              v-for="item in order.cartItems"
              :key="item.id"
              class="goods-item"
            >
              <span v-if="item.status === 1">发货</span>
              <span v-else-if="item.status === 0">未发货</span>
              <!-- 如果存在其他状态，可以添加更多的v-else-if -->
              <span v-else>未知状态</span>
              <!-- 这是一个可选的默认情况 -->
            </div>
          </td>
          <td class="goods">
            <!-- 展示商品信息 -->
            <div
              v-for="item in order.cartItems"
              :key="item.id"
              class="goods-item"
            >
              {{ item.good_name }} ×{{ item.good_num }}
            </div>
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>
  
  <script>
import axios from "axios";
import navv from "@/components/nav.vue";
import top from "@/components/top.vue";

export default {
  name: "App",
  components: {
    top,
    navv,
  },
  data() {
    return {
      orders: [],
      goodsNameCache: {}, // 用于缓存商品名称的对象
    };
  },
  created() {
    this.loadOrders();
  },
  methods: {
    async loadOrders() {
      try {
        const uid = this.$store.getters.uid;
        const response = await axios.get(
          `http://localhost:8081/api/userorder/${uid}?include_items=true`
        );
        if (Array.isArray(response.data.orders)) {
          this.orders = response.data.orders.map((order) => ({
            ...order,
            // 假设后端返回的是cartItems而不是items
            cartItems: order.cartItems.map((item) => ({
              ...item,
              // 如果后端没有返回good_name，则初始化为null或空字符串
              good_name: item.good_name || null,
            })),
          }));
          // 加载订单成功后，处理商品名称的查询
          await this.processGoodNames();
        }
      } catch (error) {
        console.error("加载订单失败", error);
      }
    },
    formatDate(dateString) {
      const date = new Date(dateString);
      const options = { year: "numeric", month: "2-digit", day: "2-digit" };
      return date.toLocaleDateString("zh-CN", options);
    },
    async fetchGoodNameById(goodId) {
      // 首先检查缓存
      if (this.goodsNameCache[goodId]) {
        return this.goodsNameCache[goodId];
      }
      try {
        const response = await axios.get(
          `http://localhost:8081/my/goods/detail/?id=${goodId}`
        );
        // 假设后端返回的数据结构为 { name: "商品名称" }
        console.log(response);
        const goodName = response.data.data.name;
        // 将查询结果缓存起来
        this.goodsNameCache[goodId] = goodName;
        return goodName;
      } catch (error) {
        console.error(`查询商品名称失败（ID: ${goodId}）`, error);
        // 可以返回一个默认值或抛出错误，这里返回null作为示例
        return null;
      }
    },
    async processGoodNames() {
      const promises = [];
      this.orders.forEach((order) => {
        order.cartItems.forEach((item) => {
          // 如果商品名称尚未设置（即为null或空字符串），则发起请求
          if (!item.good_name) {
            promises.push(
              this.fetchGoodNameById(item.good_id).then((goodName) => {
                // 直接修改cartItems中的对象属性，Vue的响应式系统通常能够检测到变化
                // 但为了保险起见，也可以使用this.$set
                // 不过在这里，由于我们直接引用了cartItems中的对象，并且没有改变它的引用，所以直接修改是可行的
                item.good_name = goodName;
              })
            );
          }
        });
      });
      // 等待所有请求完成
      await Promise.all(promises);
    },
    // formatDate 方法保持不变
  },
};
</script>
  
  <style>
.order-list {
  width: 550px;
  margin: 0 auto;
  padding: 0;
}

.cart td {
  padding: 26px 15px;
  vertical-align: top;
  border-bottom: 1px solid #eee;
}

.btou {
  background: #f5f5f5;
  font-weight: bold;
}

.cartlist {
  transition: background 0.2s;
}

.cartlist:hover {
  background: #f9f9f9;
}

.goods-item {
  padding: 4px 0;
  line-height: 1.5;
}

/* 列宽调整 */
.spn {
  width: 15%;
}
.jiage {
  width: 20%;
}
.suliang {
  width: 15%;
}
.xiaoji {
  width: 15%;
}
.goods {
  width: 35%;
}
</style>