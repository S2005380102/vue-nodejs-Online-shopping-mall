<template>
  <div>
    <top></top>
    <navv></navv>
    <!-- <AddressForm style="float: left; margin-left: 200px;"></AddressForm> -->
    <AddressBook @address-selected="handleAddressSelected" />
    <table class="cart">
      <!-- <thead> -->
      <tr class="btou">
        <td class="spn">商品名称</td>
        <td class="jiage">价格</td>
        <td class="suliang">数量</td>
        <td class="xiaoji">小计</td>
      </tr>
      <!-- </thead>
      <tbody> -->
      <tr v-for="(item, index) in cartItems" :key="index" class="cartlist">
        <td class="spn">
          <img :src="item.good_img" alt="" class="sptu" />{{ item.good_name }}
        </td>
        <td class="jiage">￥{{ item.good_price.toFixed(2) }}</td>
        <td class="suliang">
          <div class="bq">{{ item.good_num }}</div>
        </td>
        <td class="xiaoji">
          ￥{{ (item.good_price * item.good_num).toFixed(2) }}
        </td>
      </tr>

      <div class="cart-sum clearfix">
        <span class="sum-money float-right" @click="submitOrder()">支付</span>
        <div class="all-money">
          <span
            ><span class="label-txt"
              ><span class="isoffer">总价</span>（不含运费）：</span
            ><span class="red_money"
              >￥<span class="big-money">{{ totalPrice }}</span></span
            ></span
          >
        </div>
      </div>
    </table>
  </div>
</template>
  
  <script>
import axios from "axios";
import navv from "@/components/nav.vue";
import top from "@/components/top.vue";
import AddressBook from "@/components/AddressBook.vue";
export default {
  name: "App",
  components: {
    top,
    navv,
    AddressBook,
  },
  data() {
    return {
      cartItems: [], // 用于存储从 localStorage 中取出的购物车商品数据
      totalPrice: 0, // 总价
      selectedAddress: null, // 存储选中的地址
    };
  },
  created() {
    this.loadCartItems(); // 在组件创建时加载购物车商品数据
  },

  methods: {
    loadCartItems() {
      const cartData = JSON.parse(localStorage.getItem("order"));
      if (Array.isArray(cartData)) {
        this.cartItems = cartData; // 将数据赋值给 cartItems
        this.calculateTotalPrice(); // 计算总价
      } else {
        console.error('localStorage 中的 "order" 数据不是一个数组');
      }
    },

    calculateTotalPrice() {
      // 计算总价
      this.totalPrice = this.cartItems.reduce((total, item) => {
        return total + item.good_price * item.good_num;
      }, 0);
    },

    handleAddressSelected(selectedAddress) {
      // 处理传递过来的地址信息
      console.log("Selected Address:", selectedAddress);
      this.selectedAddress = selectedAddress; // 存储选中的地址
    },
    async submitOrder() {
      // 提交订单，包含购物车信息和地址电话信息
      if (!this.selectedAddress) {
        console.error("No address selected!");
        return;
      }
      const order = {
        cartItems: this.cartItems,
        name: this.selectedAddress.name,
        address: this.selectedAddress.address,
        phone: this.selectedAddress.phone,
        totalPrice: this.totalPrice, // 包含总价
        uid:this.$store.getters.uid
      };
      console.log("提交订单", order);

      axios
        .post("http://localhost:8081/api/addorder", order)
        .then((response) => {
          // 请求成功时的处理
          console.log("订单提交成功", response.data);
          // 您可以在这里处理服务器的响应，比如显示成功消息、重定向到另一个页面等
          const currentGoodIds = this.cartItems.map(item => item.good_id); 
          const cartString = localStorage.getItem("hm_Cart_info");  
          const parsedCartItems = JSON.parse(cartString);  
          const updatedCartItems = parsedCartItems.filter(item => !currentGoodIds.includes(item.good_id));  
          localStorage.setItem("hm_Cart_info", JSON.stringify(updatedCartItems)); 
          this.cartItems = updatedCartItems;  
          this.$router.push("/");
        })
        .catch((error) => {
          // 请求失败时的处理
          console.error("订单提交失败", error);
          // 您可以在这里处理错误，比如显示错误消息给用户
        });
    },
  },
};
</script>
  
  <style>
.cart {
  width: 1200px;
  margin: 0 auto;
  padding: 0;
}

.cart td {
  padding-top: 26px;
  padding-bottom: 26px;
}

.btou {
  width: 1200px;
  display: flex;
  flex-direction: row;
  justify-content: space-around;
}

.cartlist {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
}
.bq {
  width: 120px;
  display: flex;
  flex-direction: row;
  margin: 0 auto;
}
.jian,
.jia {
  width: 20px;
  /* height: 30px; */
  padding: 0 5px 0 5px;
}
.sl {
  width: 42px;
  height: 28px;
}
.sptu {
  float: left;
  width: 70px;
  height: 70px;
}

.cart-sum {
  font-family: Arial, Tahoma, "Microsoft YaHei", "微软雅黑", "Helvetica Neue",
    Helvetica, STHeiTi, sans-serif;
  font-size: 14px;
  color: #333;
  padding: 0;
  box-shadow: 0px -2px 3px rgba(0, 0, 0, 0.2);
  width: 1226px;
  z-index: 100;
  height: 72px;
  margin: 30px 0 60px;
  background-color: #fff;
  position: relative;
}

.sum-money {
  font-family: Arial, Tahoma, "Microsoft YaHei", "微软雅黑", "Helvetica Neue",
    Helvetica, STHeiTi, sans-serif;
  float: right;
  width: 200px;
  cursor: pointer;
  font-size: 18px;
  text-align: center;
  line-height: 72px;
  height: 72px;
  -webkit-transition: all 0.2s;
  background-color: #f03400;
  color: #fff;
}

.all-money {
  font-family: Arial, Tahoma, "Microsoft YaHei", "微软雅黑", "Helvetica Neue",
    Helvetica, STHeiTi, sans-serif;
  font-size: 14px;
  margin: 0;
  padding: 0;
  color: #333;
  float: right;
  margin-right: 40px;
  padding-top: 23px;
  position: relative;
}
.label-txt {
  display: inline-block;
  width: 140px;
  text-align: right;
  color: #424242;
  font-size: 14px;
}
.red_money {
  margin-left: 10px;
  color: #c00000;
  font-size: 14px;
}
.big-money {
  font-size: 26px;
  font-weight: bold;
  color: #c00000;
}
.isoffer {
  text-align: right;
  color: #424242;
  font-size: 14px;
}
</style>