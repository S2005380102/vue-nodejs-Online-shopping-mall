<template>
    <div id="register">
      <h1>register</h1>
      <form action="#">
        <input
          v-model="username"
          id="username"
          required="required"
          placeholder="用户名"
          name="username"
          type="text"
        />
        <input
          v-model="password"
          id="password"
          required="required"
          placeholder="密码"
          name="password"
        />
        <input class="but" type="button" @click="register()" value="注册" />
      </form>
    </div>
  </template>
  
  <script>
  import { mapActions } from "vuex";
  import TimerComponent from "@/components/TimerComponent.vue";
  export default {
    components: {
      TimerComponent,
    },
    data() {
      return {
        username: "",
        password: "",
        role:1
      };
    },
    methods: {
      async register() {
        const data = new URLSearchParams();
        data.append("username", this.username.toString());
        data.append("password", this.password.toString());
        data.append("role", this.role.toString());
        try {
          const response = await fetch("http://localhost:8081/api/reguser", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: data,
          })
            .then((response) => {
              if (!response.ok) {
                throw new Error("Network response was not ok");
              }
              return response.json(); // 解析JSON格式的响应体
            })
            // 登录成功，处理返回的数据和跳转逻辑
            .then((data) => {
              // console.log(res);
              // console.log(res.body.getReader());
              console.log(data); // 这里就是响应体中的数据
              if (data.status == "0") {
                this.$router.push("/login");
                alert("注册成功请登录");
              }
            });
        } catch (error) {
          // 登录失败，处理错误
          alert("注册失败");
          console.log(error);
        }
      },
    },
    
  };
  </script>
  
  <style Scoped>
  html {
    width: 100%;
    height: 100%;
    overflow: hidden;
    font-style: sans-serif;
  }
  
  body {
    width: 100%;
    height: 100%;
    font-family: "Open Sans", sans-serif;
    margin: 0;
    background-color: #4a374a;
  }
  
  #register {
    position: absolute;
    top: 50%;
    left: 50%;
    margin: -150px 0 0 -150px;
    width: 300px;
    height: 300px;
  }
  
  #register h1 {
    color: #fff;
    text-shadow: 0 0 10px;
    letter-spacing: 1px;
    text-align: center;
  }
  
  h1 {
    font-size: 2em;
    margin: 0.67em 0;
  }
  
  input {
    width: 278px;
    height: 18px;
    margin-bottom: 10px;
    outline: none;
    padding: 10px;
    font-size: 13px;
    color: #fff;
    text-shadow: 1px 1px 1px;
    border-top: 1px solid #312e3d;
    border-left: 1px solid #312e3d;
    border-right: 1px solid #312e3d;
    border-bottom: 1px solid #56536a;
    border-radius: 4px;
    background-color: #2d2d3f;
  }
  
  .but {
    width: 300px;
    min-height: 40px;
    display: block;
    background-color: #4a77d4;
    border: 1px solid #3762bc;
    color: #fff;
    padding: 9px 14px;
    font-size: 15px;
    line-height: normal;
    border-radius: 5px;
    margin: 0;
  }
  </style>
  