<template>
  <div>
    <top></top>
    <navv></navv>
    <User_Sidebar />
    <div class="upload-avatar">
      <h2>上传头像</h2>
      <form @submit.prevent="handleAvatarUpload">
        <div>
          <label for="avatar">选择头像:</label>
          <input
            type="file"
            @change="updateAvatar($event)"
            name="file"
            id="file"
          />
        </div>
        <button type="submit">上传</button>
        <p>{{ message }}</p>
      </form>
    </div>
  </div>
</template>
 
<script>
import axios from "axios";
import User_Sidebar from "@/components/User_Sidebar.vue";
import navv from "@/components/nav.vue";
import top from "@/components/top.vue";

export default {
  components: {
    User_Sidebar,
    navv,
    top,
  },
  data() {
    return {
      formData: {
        id: this.$store.getters.uid, // 假设这是从 Vuex 中获取的用户ID
        avatar: null, // 存储选中的文件
      },
      message: "", // 用于显示操作结果或错误信息
    };
  },
  methods: {
    updateAvatar(event) {
      this.formData.avatar = event.target.files[0];
    },
    handleAvatarUpload() {
      // 创建一个新的 FormData 实例
      const formData = new FormData();
      formData.append("id", this.$store.getters.uid); // 添加用户ID
      formData.append("file", this.formData.avatar); // 添加文件

      axios
        .post("http://localhost:8081/my/update/avatar", formData) // 注意这里没有设置 headers
        .then((response) => {
          this.message = "头像上传成功";
          
        })
        .catch((error) => {
          this.message =
            "头像上传失败: " +
            (error.response ? error.response.data.message : error.message);
        });
    },
  },
};
</script>
  
  <style scoped>
.upload-avatar {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.upload-avatar label {
  display: block;
  margin-bottom: 5px;
}

.upload-avatar input[type="file"] {
  width: 100%;
  padding: 8px;
  margin-bottom: 15px;
  box-sizing: border-box;
}

.upload-avatar button {
  width: 100%;
  padding: 10px;
  background-color: #42b983;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.upload-avatar button:hover {
  background-color: #369472;
}

.upload-avatar p {
  color: red;
}
</style>