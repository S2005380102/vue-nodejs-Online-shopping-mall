// import Vue from 'vue'
import { createStore } from 'vuex';
import user from './modules/user'
import cart from './modules/cart'
import { clearCart, downloadcart, savecart, removeInfo } from '@/utils/storage'
import createPersistedState from 'vuex-persistedstate';
//Vue2写法
// Vue.use(Vuex)


const store = createStore({
    //提供数据
    state: {
        //      carts: [] //购物车
        shouldRunFiveMinuteTimer: null, 
        timerInterval: 3000 // 5 分钟 = 300000 毫秒
    },
    //扩展
    getters: {
        token(state) {
            // console.log(state.user.userInfo);
            return state.user.userInfo.token
        },
        uid(state) {
            // console.log(state.user.userInfo);
            return state.user.userInfo.uid
        },
        userid(state) {
            // console.log(state.user.userInfo);
            return state.user.userInfo.userid
        },
        user_pic(state) {
            // console.log(state.user.userInfo);
            return state.user.userInfo.user_pic
        },
        getTotalPrice(state) {
            let totalPrice = 0;
            state.carts.forEach(c => {
                totalPrice += c.price * c.num
            });
            return totalPrice;
        },
        cart(state) {
            // console.log(state.cart.CartInfo);
            return state.cart.CartInfo
        },



    },

    // //修改数方法
    mutations: {

        SET_TIMER_STATUS(state, payload) {
            state.shouldRunFiveMinuteTimer = payload; 
        },



        //     addCart(state, id) {
        //         let cart = state.carts.find(c => c.id == id)
        //         if (cart) {
        //             cart.num++;
        //         }
        //         else {
        //             let prod = state.prods.find(c => c.id == id)
        //             let cart = { ...prod, num: 1 };
        //             state.carts.push(cart);
        //         }
        //         console.log(state.carts)
        //     },

        //     delCart(state, id) {
        //         let cart = state.carts.find(c => c.id == id);
        //         let location = state.carts.indexOf(cart);
        //         state.carts.splice(location, 1);


        //     },
        //     addNum(state, id) { 
        //         let cart = state.carts.find(c => c.id == id);
        //             cart.num++;
        //     },


        //     subNum(state, id) {
        //         let cart = state.carts.find(c => c.id == id);
        //         if (cart.num > 1) {
        //             cart.num--;
        //         }
        //     }



        resetCart(state) {
            // 将 cart 重置为空数组  
            state.cart = [];
        },




    },
    // //if操作
    actions: {
        clearUser({ commit }) {
            removeInfo();
        },
        clearCart({ commit }) {
            clearCart();
        },
        savecart({ commit }) {
            savecart();
        },
        downloadcart({ commit }, payload) {
            const uid = payload
            console.log(uid);
            downloadcart(uid);
        },



        // startFiveMinuteTimer({ commit, dispatch, state }) {
        //     console.log('开始倒计时1分钟');
        //     state.fiveMinuteTimer = setInterval(() => {
        //         console.log('1分钟定时器触发');

        //     }, 10 * 1000);
        // },

        // stopFiveMinuteTimer({ state }) {
        //     if (state.fiveMinuteTimer) {
        //         clearInterval(state.fiveMinuteTimer);
        //         state.fiveMinuteTimer = null; // 清理引用  
        //         console.log('删除定时器');
        //     }
        // },


        startTimerAction({ commit }) {
            commit('SET_TIMER_STATUS', true);
        },
        stopTimerAction({ commit }) {
            commit('SET_TIMER_STATUS', false);
        }



    },
    modules: {
        user, cart
    },
    plugins: [createPersistedState({
        // key: 'time',
        storage: window.localStorage,
        // keys: ['shouldRunFiveMinuteTimer', 'timerInterval'] // 只持久化这些键对应的状态  
        reducer(state) {  
            // 只持久化 state 中的 shouldRunFiveMinuteTimer 和 timerInterval 属性  
            return {  
              shouldRunFiveMinuteTimer: state.shouldRunFiveMinuteTimer,  
              timerInterval: state.timerInterval,  
              // 如果需要，你也可以添加其他想要持久化的属性  
              // 例如：customProperty: state.someOtherProperty  
            };  
          }  

    })],




})
export default store;
// export default createStore({
//     state() {
//       return {
//         count: 0
//       };
//     },
//     mutations: {
//       increment(state) {
//         state.count++;
//       }
//     },
//   });