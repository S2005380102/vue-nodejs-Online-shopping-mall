import axios from "axios";
import { getCart, setCart } from '@/utils/storage'

import Cart from "@/views/cart.vue";
export default {
    // async fetchProducts() {
    //     try {
    //       const response = await axios.get(
    //         "http://localhost:8081/my/goods/goods"
    //       );

    //       console.log(response);
    //       console.log(123456789);
    //       return response.data.data
    //     } catch (error) {
    //       console.error("获取商品列表失败:", error);
    //     }
    //   },



    namespaced: true,
    //提供数据
    state() {
        //     prods: [],
        //     carts: [],  //购物车
        return {
            // carts:[]
            CartInfo: getCart()
        }
    },
    //扩展
    getters: {
        // cart1(state){
        //     return state.index.carts
        // }
        // carts: state => state.carts 
        carts: state => state.CartInfo
    },
    // //修改数方法
    mutations: {
        addCart(state,{id,quantity,uid}) {
            console.log(quantity);
            var num = quantity;
            
            try {
                axios.get("http://localhost:8081/api/goodscart")
                    .then(r => {
                        // let cart;
                        let carts = getCart() //缓存中的购物车
                        let cart = ""
                        this.prods = r.data.data
                        console.log(carts);
                        if (carts != undefined) {      //缓存中购物车存在
                            cart = carts.find(c => c.good_id == id) //从carts筛选出id一样的放进cart
                        }
                        if (cart) {                    //如果找到了商品
                            for (var i = 0; i < carts.length; i++) {//遍历整个购物车
                                if (carts[i].good_id == id) {//寻找到ID一样的商品
                                    // carts[i].num++;
                                    carts[i].good_num+=num   //添加数量进去
                                    break
                                }

                            }
                            setCart(carts)  //存入购物车

                        } else {  //没找到商品
                            // if (state.carts != null) {           
                            let prod = this.prods.find(c => c.good_id == id)//在数据库里筛选商品出来
                            let cart = { ...prod, good_num: num,uid:uid };//把商品添加进cart，并且加入数量字段
                            
                            carts.push(cart) //把cart存入VUEX里面的carts，cart其实是单样商品
                            setCart(carts)  //存入购物车
   
                        }
                        // console.log(state.carts);

                    })

            } catch (error) {
                console.error("获取商品列表失败:", error);
            }
            // let prod = this.prod.find(c => c.id == id)
            // let cart = { ...prod, num: 1 };
            // state.carts.push(cart);
            // }
            // let cart =  {'id':id,'num':1};
            // state.carts.push(cart);

        },

        delCart(state, id) {
            let carts = [...state.CartInfo];  
            console.log(id);
            carts = carts.filter(cart => cart.good_id != id.id);  //通过ID数据筛选掉数据
            setCart(carts);                                  //覆盖存入
        },
        updateCartItem(state, { index, num }) {
            let carts = [...state.CartInfo];
            if (index >= 0 && index < carts.length) {
                carts[index].good_num = num;
                setCart(carts);
            }
        }
    },
    // //if操作
    actions: {
        updateCartItem({ commit }, payload) {
            commit('updateCartItem', payload);
        }
    },
    modules: {

    }
    ,
}

