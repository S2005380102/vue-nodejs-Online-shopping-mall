
import {getInfo,setInfo} from '@/utils/storage'
import axios from 'axios';
export default{
    namespaced:true,
    //提供数据
    state(){
        return{
            //个人权证
            // userInfo:{
            //     token:'',
            //     userId:'',
              
            // }
            userInfo:getInfo()
        }
    },
    //修改数方法
    mutations:{
        //所有Mutations第一个参数是state
        setUserInfo(state,obj){
            state.userInfo = obj;  
            setInfo(obj)
         }
    },
    //if操作
    actions: {
    },
    //扩展
    getters:{}
}

// // store/modules/user.js
// import axios from 'axios';
// import { getInfo, setInfo } from '@/utils/storage';
 
// export default {
//   namespaced: true,
//   // 提供数据
//   state() {
//     // 从本地存储加载用户信息
//     const userInfo = getInfo() || {};
//     return {
//       userInfo,
//     };
//   },
//   // 修改数据的方法
//   mutations: {
//     // 所有Mutations第一个参数是state
//     setUserInfo(state, obj) {
//       state.userInfo = obj;
//       // 更新本地存储
//       setInfo(obj);
//     },
//   },
//   // 异步操作
//   actions: {
//     async fetchUserInfo({ commit }) {
//         commit('setLoading', true); // 开始加载数据
//         try {
//           // 尝试从服务器获取用户信息

//           console.log(userInfo.uid);
//           const response = await axios.get('http://localhost:8081/my/userinfo?id='+userInfo.uid); // 替换为实际的API端点
//           const userInfo = response.data; // 假设服务器返回的数据在response.data中
//           commit('setUserInfo', userInfo); // 更新Vuex store中的用户信息
//         } catch (error) {
//           console.error('Failed to fetch user info:', error); // 处理错误
//           // 这里可以选择回退到本地存储的用户信息或其他逻辑
//         } finally {
//           commit('setLoading', false); // 结束加载数据
//         }
//       },
//       async updateUserInfo({ commit }, newUserInfo) {
//         // 这里可以添加将用户信息发送到服务器的逻辑
//         try {
//           const response = await axios.post('/api/user/update', newUserInfo); // 替换为实际的API端点
//           // 假设服务器返回了更新后的用户信息（这取决于您的API设计）
//           const updatedUserInfo = response.data;
//           commit('setUserInfo', updatedUserInfo); // 更新Vuex store中的用户信息
//           // 如果服务器没有返回更新后的用户信息，但您知道更新是成功的，
//           // 则可以直接使用传入的newUserInfo进行更新，如上面的原始代码所示。
//         } catch (error) {
//           console.error('Failed to update user info:', error); // 处理错误
//         }
//       },
//     },
//   // 扩展
//   getters: {
//     user: (state) => state.userInfo,
//   },
// };