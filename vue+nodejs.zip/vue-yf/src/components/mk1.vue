<template>
  <div class="mk1">
    <div class="lbt">
      <!-- <img src="../assets/tu/5A浓香/5A浓香主图1.jpg" alt=""> -->
      <div class="carousel">
        <div class="carousel-slides">
          <img
            v-for="(image, index) in images"
            :key="index"
            :src="image"
            :style="{ left: index * 100 + '%', transform: dynamicstyle }"
            alt="暂无图片"
          />
        </div>
      </div>
    </div>
    <div class="new">
      <div class="bt">
        <div><span>商品资讯</span></div>
        <div><a href="/news">更多</a></div>
      </div>
      <div class="stitles">
        <div v-for="(articles, index) in formattedArticles" :key="index" class="titles">
          <div>
            <span class="title" @click="goToNews(articles.id)">{{ articles.title }}</span>
          </div>
          <div>
            <span class="time">{{ articles.formattedTime  }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
var index = 0;
//效果
import axios from "axios";
export default {
  data() {
    return {
      article: [],
      images: [
        require("@/assets/tu/商品/奥克斯冰箱.jpg"),
        require("@/assets/tu/商品/机械狗.jpg"),
        require("@/assets/tu/商品/汽车.jpg"),
        require("@/assets/tu/商品/二手苹果手机.jpg"),
        require("@/assets/tu/商品/钢琴.jpg"),
      ],

      dynamicstyle: "", //动态样式
      currentSlide: 0, //播放序号
      interval: Object,
    };
  },
  mounted() {
    this.fetchNews();
    // 自动播放动画
    this.startSlideshow();
  },
  methods: {
    async fetchNews() {
      try {
        const response = await axios.get("http://localhost:8081/api/newslist");
        // 假设后端返回的数据结构为 { data: [...] }，其中data是新闻列表数组
        console.log(response.data.data);

        const newsList = response.data.data;
        // 只取最新的7条新闻（根据时间字段排序，这里假设时间字段为time，且为ISO格式字符串）
        const sortedNews = newsList
          .slice()
          .sort((a, b) => new Date(b.time) - new Date(a.time))
          .slice(0, 7);
        // 更新articles数据
        this.article = sortedNews;
      } catch (error) {
        console.error("获取新闻列表失败:", error);
        // 可以在这里处理错误，比如显示错误消息
      }
    },

    // 图片动画
    setStyle() {
      this.dynamicstyle = `translatex(-${this.currentSlide * 100}%)`;
    },
    // 定时器
    startSlideshow() {
      this.interval = setInterval(() => {
        this.currentSlide = (this.currentSlide + 1) % this.images.length;
        this.setStyle();
      }, 3000);
    },
    stopSlideshow() {
      clearInterval(this.interval);
    },

    formatDate(dateStr) {
      const date = new Date(dateStr);
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, "0"); // 月份从0开始，需要加1
      const day = String(date.getDate()).padStart(2, "0");
      return `${year}/${month}/${day}`;
    },
    goToNews(id) {  
      this.$router.push(`/news_Detail?id=${id}`);    
    }
  },

  computed: {
    // ... 其他计算属性

    formattedArticles() {
      return this.article.map((article) => ({
        ...article,
        formattedTime: this.formatDate(article.time), // 使用辅助函数格式化日期
      }));
    },
  },
};
</script>

<style scoped>
.mk1 {
  width: 1100px;
  margin: 0 auto;
  display: flex;
  flex-direction: row;
}

.bt {
  display: flex;
  flex-direction: row;
  width: 600px;
  background: #dbeef4;
  border-left: 5px solid #0faa9c;
  padding: 15px;
  font-size: 20px;
  justify-content: space-between;
}
.bt a {
  float: right;
  font-size: 15px;
}

.imgBox {
  border-top: 2px solid cadetblue;
  width: 100%;
  height: 250px;
  margin: 0 auto;
}

.imgBox img {
  width: 100%;
  height: 250px;
  margin: 0 auto;
  padding-top: 30px;
}

.img1 {
  display: block;
}

.img2 {
  display: none;
}

.img3 {
  display: none;
}

.carousel {
  position: relative;
}
.carousel-slides {
  position: relative;
  width: 450px;
  height: 450px;
  overflow: hidden;
}
.carousel-slides img {
  display: inline-block;
  position: absolute;
  width: inherit;
  margin: 0;
  padding: 0;
  top: 0;
  left: 0;
  height: 100%;
  transition: 0.5s transform ease-in-out;
}
.carousel-controls {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  justify-content: center;
}

.titles {
  width: 600px;
  margin-top: 10px;
  line-height: 40px;
  border-bottom: darkgray 1px solid;
}
.title {
  float: left;
  font-size: 18px;
}
.title:hover {
  cursor: pointer;
  color: #0faa9c;
}
.time {
  float: right;
  font-size: 15px;
  color: darkgray;
}
.stitles {
  display: flex;
  flex-direction: column;
  width: 650px;
  margin-left: 8px;
}
.new {
  width: 650px;
  margin-left: 15px;
  font-family: "微软雅黑";
}
</style>