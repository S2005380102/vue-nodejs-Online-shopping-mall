<template>
  <div class="AddressItem-all-all">
    <span class="AddressItem-title">收货地址</span>
    <div class="AddressItem-all">
      <div
        v-for="(address, index) in addresses"
        :key="index"
        class="AddressItem"
        :class="{ selected: selectedIndex === index }"
        @click="selectAddress(index)"
        @mouseover="showEditButton(index)"
        @mouseleave="hideEditButton(index)"
      >
        <div>
          <span class="AddressItem-name">{{ address.name }}</span>
          <span class="AddressItem-tel">{{ address.phone }}</span>
        </div>
        <div class="AddressItem-dz">
          <span>{{ address.province }}</span>
          <!-- 假设dz字段是省份+城市，这里简单展示 -->
          <span>{{ address.city }}</span>
          <!-- 需要根据实际情况调整 -->
        </div>
        <div class="AddressItem-xxdz">
          <span>{{ address.address }}</span>
        </div>
        <div class="AddressItem-xzbm">
          <span>邮政编码:{{ address.postalCode }}</span>
        </div>

        <div class="AddressItem-edit" v-if="showEditIndexes.includes(index)">
          <button @click="editAddress(index)">修改</button>
        </div>

        <div v-if="editingIndex !== null" class="AddressItem-edit-form-overlay">
          <div class="AddressItem-edit-form-container">
            <form @submit.prevent="updateAddress(editingIndex, $event)">
              <!-- 表单内容 -->
              <div>
                <label>姓名:</label>
                <input
                  type="text"
                  v-model="editForms[editingIndex].name"
                  required
                />
              </div>
              <div>
                <label>电话:</label>
                <input
                  type="text"
                  v-model="editForms[editingIndex].phone"
                  required
                />
              </div>
              <div>
                <label>省份:</label>
                <input
                  type="text"
                  v-model="editForms[editingIndex].province"
                  required
                />
              </div>
              <div>
                <label>城市:</label>
                <input
                  type="text"
                  v-model="editForms[editingIndex].city"
                  required
                />
              </div>
              <div>
                <label>详细地址:</label>
                <input
                  type="text"
                  v-model="editForms[editingIndex].address"
                  required
                />
              </div>
              <div>
                <label>邮政编码:</label>
                <input
                  type="text"
                  v-model="editForms[editingIndex].postalCode"
                  required
                />
              </div>

              <button type="submit">保存</button>
              <button type="button" @click="cancelEdit(editingIndex)">
                取消
              </button>
            </form>
          </div>
        </div>

        <div class="AddressItem-delete" v-if="showEditIndexes.includes(index)">
          <button @click="showDeleteConfirmation(index)">X</button>
        </div>

        <!-- 删除确认模态框（简单实现） -->
        <div
          v-if="confirmDeleteIndex === index"
          class="AddressItem-delete-confirmation"
        >
          <p>确定要删除这个地址吗？</p>
          <button @click="confirmDeleteAddress(index)">确定</button>
          <button @click="cancelDeleteConfirmation(index)">取消</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      addresses: [], // 用于存储从接口获取的地址数据
      selectedIndex: null, // 用于存储当前选中地址的索引
      showEditIndexes: [], // 用于存储显示编辑按钮的地址索引
      editingIndex: null, // 当前正在编辑的地址索引
      editForms: {}, // 存储编辑表单的数据
      confirmDeleteIndex: null, // 用于存储当前要确认删除的地址索引
    };
  },
  created() {
    this.fetchAddresses(); // 在组件创建时获取数据
  },
  methods: {
    async fetchAddresses() {
      try {
        const uid=this.$store.getters.uid
        const response = await fetch("http://localhost:8081/api/GetAddress/"+uid); // 替换为你的API接口地址
        const data = await response.json();
        this.addresses = data.data;
        // 初始化 editForms
        this.editForms = this.addresses.reduce((acc, cur, idx) => {
          acc[idx] = { ...cur };
          return acc;
        }, {});
        if (this.addresses.length > 0) {
          this.selectAddress(0);
        }
      } catch (error) {
        console.error("获取地址失败", error);
      }
    },
    selectAddress(index) {
      this.selectedIndex = index;
      this.$emit("address-selected", this.addresses[index]);
    },

    showEditButton(index) {
      if (!this.showEditIndexes.includes(index)) {
        this.showEditIndexes.push(index);
      }
    },
    hideEditButton(index) {
      this.showEditIndexes = this.showEditIndexes.filter((i) => i !== index);
    },
    hideAllEditButtons() {
      this.showEditIndexes = [];
    },
    editAddress(index) {
      this.editingIndex = index;
    },
    cancelEdit(index) {
      this.editingIndex = null;
    },
    async updateAddress(index, event) {
      try {
        const uid = this.$store.getters.uid; // 替换为实际的 uid 值
        const formData = { ...this.editForms[index], uid: uid };

        const response = await fetch("http://localhost:8081/api/UpAddress", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        });
        const { status, message } = await response.json();
        if (response.ok && status === 0) {
          alert("修改成功");
          location.reload(true);
        } else {
          console.error("更新地址失败", message);
        }
      } catch (error) {
        console.error("更新地址时网络错误", error);
      }
    },

    showDeleteConfirmation(index) {
      this.confirmDeleteIndex = index;
    },

    cancelDeleteConfirmation(index) {
      this.confirmDeleteIndex = null;
    },

    async confirmDeleteAddress(index) {
      try {
        const response = await fetch("http://localhost:8081/api/DelAddress", {
          method: "POST", // 根据后端API要求，可能是DELETE方法或其他
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            uid: this.$store.getters.uid,
            id: this.addresses[index].id,
          }), // 假设后端需要uid和addressId来删除地址
        });

        const { status, message } = await response.json();
        if (response.ok && status === 0) {
          alert("删除成功");
          this.addresses = this.addresses.filter((_, i) => i !== index); // 从本地列表中移除已删除的地址
          this.editForms = this.addresses.reduce((acc, cur, idx) => {
            acc[idx] = { ...cur };
            return acc;
          }, {}); // 更新editForms以匹配新的addresses数组
          this.confirmDeleteIndex = null; // 隐藏删除确认模态框
          // 注意：这里没有重新加载页面，因为我们已经更新了本地数据
        } else {
          console.error("删除地址失败", message);
        }
      } catch (error) {
        console.error("删除地址时网络错误", error);
      }
    },
  },
};
</script>  

<style>
.AddressItem-title {
  font-size: 25px;
  font-weight: bolder;
}
.AddressItem-all-all {
  width: 1200px;
  margin: 20px auto;
}
.AddressItem-all {
  flex-wrap: wrap;
  display: flex;
  width: 1200px;
  margin: 15px auto;
  justify-content: flex-start;
}
.AddressItem {
  position: relative;
  margin-top: 15px;
  margin-right: 15px;
  padding: 15px;
  width: 250px;
  height: 140px;
  border: 1px solid #b8b8b8;
  transition: border-color 0.3s; /* 添加过渡效果 */
}
.AddressItem.selected {
  border: 2px solid #ff3600;
}
.AddressItem:hover {
  border: 2px solid #ff3600;
}
.AddressItem-name {
  font-weight: bolder;
  font-size: 18px;
}
.AddressItem-dz {
  color: #757575;
  margin-top: 10px;
}
.AddressItem-xxdz {
  font-size: 13px;
  color: #757575;
  margin-top: 5px;
}
.AddressItem-xxdz span {
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 3;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: normal;
}
.AddressItem-tel {
  margin-left: 5px;
  color: #757575;
}
.AddressItem-xzbm {
  position: absolute;
  bottom: 15px;
  font-size: 13px;
  color: #757575;
}

.AddressItem-edit {
  display: flex;
  justify-content: flex-end;
  margin-top: 10px;
}

.AddressItem-edit-form-overlay {
  position: fixed; /* 固定定位 */
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5); /* 半透明背景 */
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000; /* 确保其位于其他内容之上 */
}

.AddressItem-edit-form-container {
  background-color: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  width: 400px; /* 表单宽度 */
  max-width: 90%; /* 在小屏幕上自适应 */
  box-sizing: border-box;
}

.AddressItem-edit-form-container form {
  display: flex;
  flex-direction: column;
}

.AddressItem-edit-form-container label {
  font-weight: bold;
  margin-bottom: 5px;
}

.AddressItem-edit-form-container input {
  margin-bottom: 15px;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.AddressItem-edit-form-container button {
  padding: 10px 15px;
  margin-top: 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.AddressItem-edit-form-container button[type="submit"] {
  background-color: #4caf50;
  color: white;
}

.AddressItem-edit-form-container button[type="button"] {
  background-color: #f44336;
  color: white;
  margin-left: 10px;
}

.AddressItem-edit-form-container button:hover {
  opacity: 0.9;
}

/* 添加一些样式来控制删除按钮和确认模态框的显示 */
.AddressItem-delete {
  position: absolute; /* 或其他布局方式，确保按钮在地址框内且不影响其他内容 */
  right: 10px; /* 根据需要调整位置 */
  top: 10px; /* 根据需要调整位置 */
  cursor: pointer;
}

.AddressItem-delete-confirmation {
  position: fixed; /* 或其他布局方式，确保模态框覆盖整个屏幕或需要覆盖的区域 */
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: white;
  border: 1px solid #ccc;
  padding: 20px;
  z-index: 1000; /* 确保模态框在最上层 */
}
</style>


