<template>
      <div class="nav">
        <div>
            <router-link to="/">首页</router-link>
            <router-link to="/commodity">商品商城</router-link>
            <router-link to="/news">新闻公告</router-link>
            <router-link to="/serve">商品服务</router-link>
            <router-link to="/newproduct">最新商品</router-link>
            <router-link to="/link">友情链接</router-link>
            <!-- <a href="">新闻公告</a>
            <a href="">商品服务</a>
            <a href="">最新商品</a>
            <a href="">数字资源</a>
            <a href="">友情链接</a> -->
        </div>

    </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.nav{
    width: 100%;
    background: #0faa9c;
    margin: 0 auto;
    padding: 15px;
    margin-top: 5px;
}
.nav div{
    width: 1200px;
    margin: 0 auto;
    display: flex;
    flex-direction:row;
    justify-content: space-around;
}
.nav a{
    color: white;
    font-style: normal;
    text-decoration: none;
    font-weight: bolder;
    font-size: 20px;
}
</style>