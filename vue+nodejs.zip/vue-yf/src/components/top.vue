<template>
  <div>
    <div class="tophead">
      <div class="tophead1">
        <div class="topwenzi">
          <div v-if="user" class="topwenzi">
            <div class="topwenzi1">
              <span>欢迎您！</span>
              <router-link to="/User_Profile" class="username">
                <img
                  v-if="userpicture"
                  :src="userpicture"
                  alt=""
                  class="tx_img"
                />
                <a style="margin-right: 0">
                  {{ user }}
                </a>
              </router-link>
              <router-link to="/" @click="logout()">退出</router-link>
            </div>
          </div>
          <div v-else class="topwenzi">
            <div class="topwenzi1">
              <router-link to="/login">登录</router-link>
            </div>
            <div>
              <a href="register">注册</a>
            </div>
          </div>
        </div>
        <div class="topwenzi">
          <a href="/myorder">我的订单</a>
        </div>
        <div class="cart-info">
          <router-link to="/cart" class="cart-num">购物车</router-link>
        </div>
      </div>
    </div>
    <div class="banner">
      <img src="../assets/tu/1.png" alt="" />
    </div>
    <TimerComponent />
  </div>
</template>

<script>
import { mapActions } from "vuex";
import TimerComponent from "@/components/TimerComponent.vue";
export default {
  components: {
    TimerComponent,
  },
  data() {
    return {
      userpicture: this.$store.getters.user_pic,
      user: this.$store.getters.userid,
    };
  },
  methods: {
    ...mapActions(["startTimerAction", "stopTimerAction"]),
    startTimer() {
      this.startTimerAction(); // 这个 action 应该设置 shouldRunFiveMinuteTimer 为 true
    },
    stopTimer() {
      this.stopTimerAction(); // 这个 action 应该设置 shouldRunFiveMinuteTimer 为 false
    },

    logout() {
      // this.$store.dispatch('stopFiveMinuteTimer');
      this.stopTimer();
      this.$store.dispatch("savecart");
      this.$store.dispatch("clearCart");
      this.$store.dispatch("clearUser");
      location.reload(true);
    },
  },
};
</script>

<style scoped>
.tophead {
  height: 40px;
  background-color: #264653;
  margin-bottom: 5px;
}
.banner {
  width: 1200px;
  height: 300.5px;
  margin: 0 auto;
}
.banner img {
  width: 1200px;
  height: 300px;
  object-fit: cover;
}

.cart-num {
  display: flex;
  justify-content: center;
  font-size: 16px;
  color: #333;
  line-height: 40px;
}
.tophead1 {
  display: flex;
  justify-content: flex-end;
}
.cart-info {
  margin-right: 120px;
  float: right;
  width: 120px;
  height: 40px;
  background-color: #ff3600;
}
.topwenzi {
  display: flex;
  justify-content: flex-end;
}
.topwenzi a {
  color: #b0b0b0;
  line-height: 40px;
  font-size: 14px;
  margin-right: 30px;
}
.topwenzi a:hover {
  color: #ff3600;
  line-height: 40px;
  font-size: 14px;
  margin-right: 30px;
}
.topwenzi span {
  color: #b0b0b0;
  line-height: 40px;
  font-size: 14px;
}
.tx_img {
  margin-top: 5px;
  margin-right: 5px;
  width: 30px;
  height: 30px;
  border-radius: 50%;
}
.topwenzi1 {
  display: flex;
  height: 40px;
}
.username {
  display: flex;
  color: #b0b0b0;
  line-height: 40px;
  font-size: 14px;
}
.username:hover {
  display: flex;
  color: #ff3600;
  line-height: 40px;
  font-size: 14px;
}
</style>