<template>  
    <div>  
      <!-- 你的组件模板 -->  
    </div>  
  </template>  
    
  <script>  
  import { ref, onMounted, onUnmounted } from 'vue';  
  import { useStore } from 'vuex';  
    
  export default {  
    setup() {  
      const store = useStore();  
      const timerId = ref(null);  
    
      const startTimer = () => {
          console.log("开始" ) 
          // console.log(store.state.timerInterval ) 

        if (store.state.shouldRunFiveMinuteTimer) {  
          console.log("开始1" ) 
          timerId.value = setInterval(() => {  
            // 触发你的 action 或其他逻辑  
            console.log("触发计时器");
            store.dispatch('savecart');  
          }, store.state.timerInterval);  
        }  
      };  
    
      const stopTimer = () => {  
        if (timerId.value !== null) {  
          clearInterval(timerId.value);  
          timerId.value = null;  
        }  
      };  
    
      onMounted(() => {  
        startTimer();  
      });  
    
      onUnmounted(() => {  
        stopTimer();  
      });  
    
      // 返回给模板的响应式数据或函数（如果需要）  
      return {  
        // ...  
      };  
    },  
  };  
  </script>