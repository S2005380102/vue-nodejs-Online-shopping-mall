<template>
  <div class="mk2">
    <!-- <div class="teatitle">茶叶商城</div>
      <div class="Selected">Tea shop</div> -->
    <div>
      <div class="tea">
        <!-- {{ products }} -->
        <div v-for="(teas, index) in products" :key="index" class="teax"  @click="goToGoods(teas.id)">
          <img v-if="teas.picture" :src="teas.picture" alt="" class="img"  />
          <span class="teaname"> {{ teas.name }}</span>
          <span class="teaprice">￥{{ teas.price }}/件</span>
        </div>
      </div>
    </div>
  </div>
</template>
  
  <script>
import axios from "axios";

export default {
  data() {
    return {
      products: [], // 用于存储商品列表的数据
    };
  },
  created() {
    this.fetchProducts();
  },
  methods: {
    async fetchProducts() {
      try {
        const response = await axios.get(
          "http://localhost:8081/my/goods/agoods"
        );
        this.products = response.data.data;
        console.log(this.products);
      } catch (error) {
        console.error("获取商品列表失败:", error);
      }
    },

    goToGoods(id) {  
      this.$router.push(`/commodity_Detail?id=${id}`);    
    }


    
  },
};
</script>
  
  <style scoped >
/* .teatitle {
    font-weight: bold;
    font-size: 35px;
    line-height: 40px;
    
  }
  .Selected {
    font-size: 12px;
    color: #b0b0b0;
    font-weight: normal;
  } */
.mk2 {
  width: 1100px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  margin-top: 20px;
}
.img {
  /* border-radius:5% 5% 0% 0%; */
  width: 100%;
  float: left;
  height: 190px;
  margin-bottom: 10px;
}
.teax {
  margin-top: 20px;
  margin-bottom: 20px;
  float: left;
  width: 200.286px;
  display: flex;
  flex-direction: column;
  background: #ffffff;
  border-radius: 5%;
  margin-right: 15px;
  margin-left: 15px;
}
.teax span {
  text-align: center;
  font-size: 14px;
  line-height: 30px;
}
.teaprice {
  color: rgb(255, 56, 56);
  font-size: 16px;
  font-weight: normal;
}
.tea {
  display: flex;
  flex-direction: row;
  justify-content: center;
  flex-wrap:wrap;
}
.teax:first-child {
  margin-left: 0;
}
.teax:last-child {
  margin-right: 0;
}

.teaname {
  font-size: 16px;
  color: rgb(86, 87, 101);
}
</style>