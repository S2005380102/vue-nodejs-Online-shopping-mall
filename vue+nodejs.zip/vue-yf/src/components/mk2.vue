<template>
  <div class="mk2">
    <div class="teatitle">精选商品</div>
    <div class="Selected">Selected Goods</div>
    <div>
      <div class="tea">
        <div v-for="(teas, index) in tea" :key="index" class="teax">
          <img :src="teas.image" alt="" class="img" />
          <span class="teaname"> {{ teas.name }}</span>
          <span class="teaprice">￥{{ teas.price }}/件</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tea: [
        {
          id: 1,
          name: "二手苹果手机",
          price: 50000,
          image: require("@/assets/tu/商品/二手苹果手机.jpg"),
        },{
          id: 1,
          name: "钢琴",
          price: 20000,
          image: require("@/assets/tu/商品/钢琴.jpg"),
        },{
          id: 1,
          name: "机械狗",
          price: 21999,
          image: require("@/assets/tu/商品/机械狗.jpg"),
        },{
          id: 1,
          name: "汽车",
          price: 9000000,
          image: require("@/assets/tu/商品/汽车.jpg"),
        },
        {
          id: 1,
          name: "奥克斯冰箱",
          price: 298,
          image: require("@/assets/tu/商品/奥克斯冰箱.jpg"),
        },
      ],
    };
  },
};
</script>

<style scoped >
.teatitle {
  font-size: 30px;
  line-height: 40px;
}
.Selected {
  font-size: 12px;
  color: #b0b0b0;
  font-weight: normal;
}
.mk2 {
  width: 1100px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  margin-top: 20px;
}
.img {
  border-radius:5% 5% 0% 0%;
  width: 100%;
  float: left;
  height: 190px;
  margin-bottom: 10px;
}
.teax {
  margin-top: 20px;
  margin-bottom: 20px;
  float: left;
  width: 200.286px;
  display: flex;
  flex-direction: column;
  background: #ffffff;
  border-radius:5%;
  margin-right: 15px;
  margin-left: 15px;
}
.teax span {
  text-align: center;
  font-size: 14px;
  line-height: 30px;
}
.teaprice {
  color: #c61821;
  font-size: 16px;
  font-weight: normal;
}
.tea{
  display: flex;
  flex-direction: row;
  justify-content: center;
}
.teax:first-child{
  margin-left:0;
}
.teax:last-child{
  margin-right:0;
}
</style>