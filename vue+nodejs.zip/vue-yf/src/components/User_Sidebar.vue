<template>
  <div class="sidebar">
    <ul>
      <li><router-link to="/User_Address">收货地址管理</router-link></li>
      <li><router-link to="/User_Profile">用户资料</router-link></li>
      <li><router-link to="/User_Password">重置密码</router-link></li>
      <li><router-link to="/User_Avatar">上传头像</router-link></li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'User_Sidebar'
}
</script>

<style scoped>
.sidebar {
  /* 侧边栏样式 */
  width: 200px;
  background-color: #f3f3f3;
  position: absolute; /* 固定侧边栏位置 */
  top: 415px;
  bottom: 0;
  height: 100vh; /* 使侧边栏高度占满视窗高度 */
  padding-top: 20px; /* 为顶部留出一些空间 */
  box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1); /* 添加阴影效果 */
}

.sidebar ul {
  /* 列表样式 */
  list-style-type: none;
  padding: 0;
  margin: 0;
  width: 100%;
}

.sidebar li {
  /* 列表项样式 */
  padding: 10px;
  border-bottom: 1px solid #ddd; /* 添加底部边框 */
  transition: background-color 0.3s; /* 添加背景色过渡效果 */
}

.sidebar li:hover {
  /* 悬停效果 */
  background-color: #e0e0e0;
}

.sidebar a {
  /* 链接样式 */
  text-decoration: none;
  color: #333;
  font-size: 16px; /* 设置字体大小 */
  display: block; /* 使链接占据整行 */
  width: 100%;
  padding: 5px 0; /* 上下内边距，用于增加点击区域 */
  text-align: center; /* 文字居中 */
}

.sidebar a:hover {
  /* 链接悬停效果，可以添加颜色变化等 */
  color: #007bff;
}
</style>