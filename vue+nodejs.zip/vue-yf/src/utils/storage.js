//导入axios
import axios from 'axios';
//通用键名
const INFO_KEY = 'hm_user_info'
const Cart_KEY = 'hm_Cart_info'
//获取个人信息
export const getInfo = () => {
    const defaultObj = { token: '', userId: '', uid: '' }
    const result = localStorage.getItem(INFO_KEY)
    return result ? JSON.parse(result) : defaultObj
}
//设置个人信息
export const setInfo = (obj) => {
    console.log('setInfo called with:', obj);
    console.log('INFO_KEY is:', INFO_KEY);
    // console.log('setInfo called with:', obj);
    // if (typeof obj === 'object' && obj !== null) {  
    //     localStorage.setItem(INFO_KEY, JSON.stringify(obj));  
    // } else {  
    //     console.error('setInfo: Invalid argument. Expected an object.');  
    // }  
    localStorage.setItem(INFO_KEY, JSON.stringify(obj))
    console.log('setInfo called with:', obj);
    console.log('INFO_KEY is:', INFO_KEY);
}
//移除个人信息
export const removeInfo = () => {
    localStorage.removeItem(INFO_KEY)
}




export const getCart = () => {
    // const defaultObj = {id:'',num:''}
    const defaultObj = []
    const result = localStorage.getItem(Cart_KEY)
    return result ? JSON.parse(result) : defaultObj
}
//设置购物车
export const setCart = (obj) => {

    // console.log('setInfo called with:', obj);
    // if (typeof obj === 'object' && obj !== null) {  
    //     localStorage.setItem(INFO_KEY, JSON.stringify(obj));  
    // } else {  
    //     console.error('setInfo: Invalid argument. Expected an object.');  
    // }  
    localStorage.setItem(Cart_KEY, JSON.stringify(obj))
    console.log('setInfo called with:', obj);
    console.log('Cart_KEY is:', Cart_KEY);
}


export const clearCart = () => {
    localStorage.removeItem(Cart_KEY)
    console.log("已删除购物车缓存");

}

export const savecart = (onSuccess, onError) => {
    // 定义一个异步函数来包裹实际的逻辑  
    (
        async () => {
            try {
                // 从 localStorage 获取数据  
                const cartData = JSON.parse(localStorage.getItem(Cart_KEY));

                // const cartData = localStorage.getItem(Cart_KEY);  
                // console.log(typeof(cartData));
                console.log(cartData);
                if (!cartData || cartData[0] == null) {
                    // console.log('缓存内没有数据');
                    // console.log(cartData);
                    // var uid = this.$store.getters.uid;
                    const userInfo = getInfo();
                    const clearCartResponse = await axios.post('http://localhost:8081/api/clearcart', { uid:userInfo.uid });
                    if (clearCartResponse.data.status == 0) {
                        console.log('购物车已清空');
                        if (onError) onError('购物车已清空，无数据可保存');
                        return;
                    } else {
                        if (onError) onError('清空购物车失败', clearCartResponse.data);
                        return;
                    }
                }
                // 通过接口上传数据  
                const response = await axios.post('http://localhost:8081/api/savecart', cartData);

                // 根据响应处理结果  
                if (response.data.success) {
                    if (onSuccess) onSuccess(response.data);
                    console.log('保存成功');
                    // 清空缓存 localStorage：localStorage.removeItem('Cart_KEY');  在退出登录
                } else {
                    if (onError) onError('保存失败', response.data);
                }
            } catch (error) {
                // 处理网络错误或其他异常  
                if (onError) onError('保存失败', error);
            }
        })();
}


export const downloadcart = (uid) => {
    console.log(uid);
    fetch('http://localhost:8081/api/cart/' + uid, { method: 'GET' })
        .then(response => response.json())
        .then(data => {
            const cartData = data.data ? data.data : [];
            const dataString = JSON.stringify(cartData);
            localStorage.setItem(Cart_KEY, dataString);
            console.log('Data stored in localStorage:', localStorage.getItem(Cart_KEY));

        })

        
        .catch(error => {
            console.error('Error fetching data:', error);
        });

}


