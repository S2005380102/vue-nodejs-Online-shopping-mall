// import Vue from 'vue'
// import {Dialog} from 'vant'
//
// // Vue.use(Dialog)
//以上vue2 写法



import { Dialog } from 'vant';  
import 'vant/es/dialog/style';
const install = (app) => {  
    // 使用 app.component() 方法全局注册组件  
    app.component('van-Dialog', Dialog);  
    // ... 其他组件  
  };  
    
  // 导出一个包含 install 方法的对象  
  export default {  
    install,  
  };