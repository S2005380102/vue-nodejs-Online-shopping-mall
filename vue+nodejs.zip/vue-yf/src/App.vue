
<template>
  
  <div>
    <!-- <top></top>
    <navv></navv> -->
    <div>
      <router-view></router-view>
    </div>
    <!-- <mk1></mk1>
    <mk2></mk2> -->
  </div>
</template>

<script>
import navv from "./components/nav.vue";
import top from "./components/top.vue";
import mk1 from "./components/mk1.vue";
import mk2 from "./components/mk2.vue";


export default {
  name: "App",
  components: {
    top,
    navv,
    mk1,
    mk2,
  },



  
};
</script>


<style Scoped>
body {
  margin: 0;
  background: #f3f3f3;
}
</style>



