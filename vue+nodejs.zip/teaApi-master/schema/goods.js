// 1. 导入定义验证规则的模块
// const joi = require('@hapi/joi') 版本原因用不了
const joi = require('joi');

// 校验规则
const id = joi.number().integer().required().min(1)
const mid = joi.number().integer().required().min(1)
const name = joi.string().required()
const paddress = joi.string().required()
const type = joi.number().integer().required()
const picture = joi.string().required()
const stock = joi.number().integer().min(1).required()
const price = joi.number().required().min(1)
// 3. 向外共享验证规则对象



    exports.get_goods_schema = {
        params: {
            mid
        },
    }
    exports.add_goods_schema = {
        body: {
            name,
            paddress,
            stock,
            price,
            mid,
            type,
            picture
        },
        
    }
    exports.update_goods_schema = {
        body: {
            id,
            name,
            paddress,
            stock,
            price,
            mid,
            type,
            picture
        },
        
    }
    exports.del_goods_schema = {
        body: {
            id,
        },
    }
    

