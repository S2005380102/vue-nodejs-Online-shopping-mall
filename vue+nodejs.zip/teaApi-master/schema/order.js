const joi = require('joi');  
  
// 校验规则  
const totalPriceSchema = joi.number().min(1).required();  
const addressSchema = joi.string().required();  
const phoneSchema = joi.number().integer().min(1).required(); // 通常电话号码应该是字符串，但这里按照你的要求定义为数字  
const uidSchema = joi.number().integer().required();  
const cartItemSchema = joi.object({  
    good_id: joi.number().integer().min(1).required(),  
    good_num: joi.number().integer().min(1).required()  
}).required();  
const nameSchema = joi.string().required();  
  
// 3. 向外共享验证规则对象  
exports.add_order_schema = joi.object({  
    body: joi.object({  
        cartItems: joi.array().items(cartItemSchema).required(),  
        uid: uidSchema,  
        totalPrice: totalPriceSchema,  
        name: nameSchema,  
        phone: phoneSchema,  
        address: addressSchema  
    }).required()  
}).required();