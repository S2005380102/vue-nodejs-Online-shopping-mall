// 1. 导入定义验证规则的模块
// const joi = require('@hapi/joi') 版本原因用不了
const joi = require('joi');

// 校验规则
const id = joi.number().integer().required().min(1)
const author = joi.string().min(1).max(10).required()
const content = joi.string().min(1).required()
const title = joi.string().min(1).max(20).required()
// 3. 向外共享验证规则对象



    exports.get_news_schema = {
        params: {
            id
        },
    }
    exports.add_news_schema = {
        body: {
            author,
            content,
            title,
    
        },
        
    }

        

  