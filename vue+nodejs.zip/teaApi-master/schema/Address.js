// 1. 导入定义验证规则的模块
// const joi = require('@hapi/joi') 版本原因用不了
const joi = require('joi');

// 校验规则
const id = joi.number().integer().required().min(1)
const uid = joi.number().integer().required().min(1)
const phone = joi.number().integer().required().min(1)
const name = joi.string().min(1).required()
const address = joi.string().min(1).required()
const city = joi.string().min(1).required()
const province = joi.string().min(1).required()
const postalCode = joi.string().min(1).required()
// 3. 向外共享验证规则对象
    exports.get_Address_schema = {
        params: {
            uid
        },
    }
    exports.Add_Address_schema = {
        body: {
            name,
            phone,
            address,
            city,
            province,
            postalCode,
            uid,
        },
        
    }
    exports.Update_Address_schema = {
        body: {
            uid,
            id,
            name,
            phone,
            address,
            city,
            province,
            postalCode
        },
        
    }
    exports.Del_Address_schema = {
        body: {
            uid,
            id,
        },
        
    }

        

  