// 1. 导入定义验证规则的模块
// const joi = require('@hapi/joi') 版本原因用不了
const joi = require('joi');

// 校验规则
const id = joi.number().integer().required().min(1)
const uid = joi.number().integer().required().min(1)
const good_num = joi.number().integer().min(1).required()
const good_id = joi.number().integer().required().min(1)
const good_price = joi.number().required().min(1)
const good_img = joi.string().required()
const good_name = joi.string().required()
// const good_list = joi.array().items(joi.object())

// 3. 向外共享验证规则对象



exports.get_cart_schema = {
    params: {
        uid
    },
}
exports.add_cart_schema = {
    body: {
        uid,
        good_id,
        good_num,
        good_price,
        good_img,
        good_name

    },

}

exports.update_cart_schema = {
    body: {
        id,
        uid,
        good_id,
        good_num,
    },

}



exports.clear_cart_schema = {
    body: {
        uid,
    },
}



exports.save_cart_schema = {
    body: joi.array().items(joi.object())

}

  







  // body: joi.array().items(joi.object({  
    //     uid: joi.number().integer().required(),  
    //     good_id: joi.number().integer().required().min(1),  
    //     good_name: joi.string().required(), // 商品名称是字符串  
    //     good_num: joi.number().integer().min(1).required(), // 假设商品数量至少为1  
    //     good_price: joi.number().required().min(1), // 可以是整数或浮点数  
    //     good_img:  joi.string().required(),
    // })).required()


    // body: [{
    //     uid,
    //     good_id,
    //     good_num,
    //     good_price,
    //     good_img,
    //     good_name

    // }]