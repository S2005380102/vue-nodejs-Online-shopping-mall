const express = require('express')
const router = express.Router()

// 导入购物车路由处理函数对应的模块
const news_handler = require('../router_handler/news')

// 1. 导入验证数据的中间件
const expressJoi = require('@escook/express-joi')
// 2. 导入需要的验证规则对象
const { get_news_schema,add_news_schema,update_cart_schema,delete_cart_schema} = require('../schema/news')


//获取文章列表的路由
router.get('/newslist', news_handler.getnews)
// 添加文章的路由
router.post('/addnews', expressJoi(add_news_schema), news_handler.addnews)
// 根据 Id 文章的路由
router.post('/deletecart', news_handler.deletenewsById)
// // 根据 uId 获取文章详情的路由
router.get('/news/:id', expressJoi(get_news_schema), news_handler.getnewsById)
// 根据 Id 更新文章的路由
router.post('/updatenews', news_handler.updatenewsById)

module.exports = router
