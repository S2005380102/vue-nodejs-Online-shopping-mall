const express = require('express')
const router = express.Router()

// 导入用户路由处理函数对应的模块
const Address_handler = require('../router_handler/Address')

// 1. 导入验证数据的中间件
const expressJoi = require('@escook/express-joi')
// 2. 导入需要的验证规则对象
const { get_Address_schema,Add_Address_schema,Update_Address_schema,Del_Address_schema} = require('../schema/Address')

// 添加地址
router.post('/AddAddress', expressJoi(Add_Address_schema),Address_handler.AddAddress)
// router.post('/AddAddress', Address_handler.AddAddress)
// 删除地址
router.post('/DelAddress', expressJoi(Del_Address_schema),Address_handler.DelAddress)
//更新地址
router.post('/UpAddress', expressJoi(Update_Address_schema),Address_handler.updatecartById)
//查询地址
router.get('/GetAddress/:uid', expressJoi(get_Address_schema),Address_handler.getAddress)
module.exports = router
