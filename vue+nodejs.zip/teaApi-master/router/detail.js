const express = require('express')
const router = express.Router()

// 挂载路由

// 导入路由处理函数模块
const detail_handler = require('../router_handler/detail')
// 导入验证数据的中间件

// 导入需要的验证规则对象

// 获取商品基本信息的路由
router.get('/detail', detail_handler.getdetail)

module.exports = router