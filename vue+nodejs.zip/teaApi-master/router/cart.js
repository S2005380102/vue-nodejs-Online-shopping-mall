const express = require('express')
const router = express.Router()

// 导入购物车路由处理函数对应的模块
const cart_handler = require('../router_handler/cart')

// 1. 导入验证数据的中间件
const expressJoi = require('@escook/express-joi')
// 2. 导入需要的验证规则对象
const { get_cart_schema,add_cart_schema,update_cart_schema,clear_cart_schema} = require('../schema/cart')

//获取商品部分字段的路由
router.get('/goodscart', cart_handler.goodscart)
// 添加购物车的路由
router.post('/addcart', expressJoi(add_cart_schema), cart_handler.addcart)
// 根据id清空购物车的路由
router.post('/clearcart', expressJoi(clear_cart_schema), cart_handler.clearcart)
// 根据 uId 获取购物车的路由
router.get('/cart/:uid', expressJoi(get_cart_schema), cart_handler.getcartById)
// 根据 Id 更新购物车的路由
router.post('/updatecart', expressJoi(update_cart_schema), cart_handler.updatecartById)
// 保存购物车的路由
router.post('/savecart', cart_handler.savecart)
// router.post('/savecart', expressJoi(save_cart_schema), cart_handler.savecart)
module.exports = router
