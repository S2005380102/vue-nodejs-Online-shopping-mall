const express = require('express')
const router = express.Router()

// 导入购物车路由处理函数对应的模块
const order_handler = require('../router_handler/order')

// 1. 导入验证数据的中间件
const expressJoi = require('@escook/express-joi')
// 2. 导入需要的验证规则对象
const {add_order_schema,} = require('../schema/order')


//获取订单列表的路由
// router.get('/orderlist', order_handler.getorder)
// 提交订单的路由
router.post('/addorder', expressJoi(add_order_schema), order_handler.addorder)
// 根据 Id 文章的路由
// router.post('/deletecart', expressJoi(delete_cart_schema), cart_handler.deletecartById)
// // // 根据 用户uId 获取订单的路由
// router.get('/userorder/:id', expressJoi(get_uorder_schema), order_handler.getuorderById)
router.get('/userorder/:uid', order_handler.getuserorderById)
// // // 根据 商家uId 获取订单的路由
router.get('/merchantorder/:mid', order_handler.getmerchantOrderById)
// 根据 物品Id 更新文章的路由
router.post('/updateorder', order_handler.updatemerchantById)

module.exports = router
