const express = require('express')
const router = express.Router()
const goods_handler = require('../router_handler/goods')
// 1. 导入验证数据的中间件
const expressJoi = require('@escook/express-joi')
const {del_goods_schema} = require('../schema/goods')
// 获取总商品的列表数据
router.get('/goods', goods_handler.getgoodsRouter)
// 获取过审商品的列表数据
router.get('/agoods', goods_handler.agoods)
// 添加商品
router.post('/addgoods',goods_handler.addgoods)
//更新商品
router.post('/upgoods',goods_handler.updategoodsById)
//删除商品
router.post('/delgoods', expressJoi(del_goods_schema),goods_handler.delgoods)
//审核商品
router.post('/approve',goods_handler.approveById)


module.exports = router