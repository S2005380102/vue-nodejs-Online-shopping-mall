const mysql  = require('mysql')

const db = mysql.createPool({
    host:'127.0.0.1',
    user:'root',
    password:'root',
    database:'tea'

})

// db.query('select 1',(err,results)=>{

//     if(err) return console.log(err.message)
//     console.log(results)
// })

// const sqlStr='select * from user'

// db.query(sqlStr,(err,results)=>{

//     if(err) return console.log(err.message)
//     console.log(results)
// })


const user = { username: 'Spider Man2', password: 'pcc4321' , role: '1' }
//定义待执行的SQL语句
const sqlStr =' insert into user set ? '
//执行SQL语句
db.query(sqlStr, user, (err, results) => {
if (err) return console.log(err.message)
if (results. affectedRows === 1) {
console.log('插入数据成功')
}
})
