const express = require('express')
const path = require('path');


const app = express()
//jwt 中间件
const jwt = require('jsonwebtoken')
const expressJWT = require('express-jwt')
//cors 中间件
const cors = require('cors')
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: true  }))



//body解析
// var bodyParser=require('body-parser')
// app.use(bodyParser.urlencoded({extended: false}))
// app.use(bodyParser.json())


// app.use('/uploads', express.static('./uploads'))


// 配置中间件以解析JSON格式的请求体  
// app.use(express.json()); 
// 配置解析表单数据的中间件，注意：这个中间件，只能解析 application/x-www-form-urlencoded 格式的表单数据
// app.use(express.urlencoded({ extended: false }))

// 一定要在路由之前，封装 res.cc 函数
app.use((req, res, next) => {
  // status 默认值为 1，表示失败的情况
  // err 的值，可能是一个错误对象，也可能是一个错误的描述字符串
  res.cc = function (err, status = 1) {
    res.send({
      status,
      message: err instanceof Error ? err.message : err,
    })
  }
  next()
})

// 设置静态文件目录
app.use('/img/TX', express.static(path.join(__dirname, 'img/TX')));
app.use('/img/goods', express.static(path.join(__dirname, 'img/goods')));
app.use('/img/merchant', express.static(path.join(__dirname, 'img/merchant')));
//用户路由
const userRouter = require('./router/user')
//前缀
app.use('/api', userRouter)


//收货地址路由
const AddressRouter = require('./router/Address')
//前缀
app.use('/api', AddressRouter)




// 商品路由模块
const goodsRouter = require('./router/goods')
//前缀
app.use('/my/goods', goodsRouter)



// 商品详情路由模块
const detailRouter = require('./router/detail')
//前缀
app.use('/my/goods', detailRouter)


// 购物车路由模块
const cartRouter = require('./router/cart')
//前缀
app.use('/api', cartRouter)


// 购物车路由模块
const orderRouter = require('./router/order')
//前缀
app.use('/api', orderRouter)


// 文章路由模块
const newsRouter = require('./router/news')
//前缀
app.use('/api', newsRouter)


// 导入并使用用户信息的路由模块
const userinfoRouter = require('./router/userinfo')
app.use('/my', userinfoRouter)



//这里是商家的路由








app.listen(8081, function () {
  console.log('server runing at http://127.0.0.1:8081')
})