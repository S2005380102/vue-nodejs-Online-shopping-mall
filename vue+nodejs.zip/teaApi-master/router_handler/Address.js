//这是路由处理模块

//导入数据库处理模块
const db = require('../db/index')
// 新增地址的处理函数
exports.AddAddress = (req, res) => {

    // 定义插入地址的 SQL 语句
    const sql = `insert into Address set ?`
    // 执行插入地址的 SQL 语句
    db.query(sql, req.body, (err, results) => {
        if (err) return res.cc(err)
        if (results.affectedRows !== 1) return res.cc('添加地址失败！')
        res.cc('添加地址成功！', 0)
    })
}

// 获取地址列表的处理函数
exports.getAddress = (req, res) => {
    // 定义根据 ID 获取地址列表数据的 SQL 语句
    const sql = `select * from Address where uid = ?`
    // 调用 db.query() 执行 SQL 语句
    db.query(sql, req.params.uid, (err, results) => {
        if (err) return res.cc(err)
        if (results.length == 0) return res.cc('获取地址列表数据失败！')
        res.send({
            status: 0,
            message: '获取地址列表数据成功！',
            data: results,
        })
    })
}




exports.updatecartById = (req, res) => {
    // 定义查重的 SQL 语句
    const sql = `select * from Address where id=? and uid=?`
    // 调用 db.query() 执行查重的 SQL 语句
    db.query(sql, [req.body.id, req.body.uid], (err, results) => {
        // 执行 SQL 语句失败
        if (err) return res.cc(err)
        //没查到数据
        if (results.length === 0) return res.cc('用户没有此地址')
        // 定义更新地址列表的 SQL 语句
        const sql = `update Address set ? where id=? and uid=?`
        // 执行更新文地址列表的 SQL 语句
        db.query(sql, [req.body, req.body.id, req.body.uid], (err, results) => {
            if (err) return res.cc(err)
            if (results.affectedRows !== 1) return res.cc('更新地址列表失败！')
            res.cc('更新地址列表成功！', 0)
        })
    })

}




exports.DelAddress = (req, res) => {
    // 定义标记删除的 SQL 语句
    const sql = `delete from Address where id=? and uid=?;`
    // 调用 db.query() 执行 SQL 语句
    db.query(sql, [req.body.id, req.body.uid,], (err, results) => {
        if (err) return res.cc(err)
        if (results.affectedRows !== 1) return res.cc('删除商品失败！')
        res.cc('删除商品成功！', 0)
    })
}