// 这是路由处理函数模块

// 导入数据库操作模块
const db = require('../db/index')
const joi = require('joi');





// 获取商品的处理函数
exports.goodscart = (req, res) => {
    // 定义根据 ID 获取文章分类数据的 SQL 语句
    const sql = `select id,name,price,picture from goods order by id asc`
    // 调用 db.query() 执行 SQL 语句
    db.query(sql, (err, results) => {
        // 1. 执行 SQL 语句失败
        if (err) return res.cc(err)
        // 2. 执行 SQL 语句成功 
        // 遍历结果数组，并修改字段名  
        const modifiedResults = results.map(item => ({
            good_id: item.id,
            good_name: item.name,
            good_price: item.price,
            good_img: item.picture,
        }));
        res.send({
            status: 0,
            message: '获取商品列表成功！',
            data: modifiedResults,
        })
    })
}


// 根据 Id 获取购物车的处理函数
exports.getcartById = (req, res) => {
    // 定义根据 ID 获取文章分类数据的 SQL 语句
    const sql = `select good_id,good_name,good_price,good_num,good_img,uid from carts where uid=?`
    // 调用 db.query() 执行 SQL 语句
    db.query(sql, req.params.uid, (err, results) => {
        if (err) return res.cc(err)
        if (results.length == 0) return res.cc('获取购物车数据失败！')
        res.send({
            status: 0,
            message: '获取购物车数据成功！',
            data: results,
        })
    })
}



// 新增购物车的处理函数
exports.addcart = (req, res) => {
    // 1. 定义查重的 SQL 语句
    const sql = `select * from carts where uid=? and good_id=?`
    // 2. 执行查重的 SQL 语句
    db.query(sql, [req.body.uid, req.body.good_id], (err, results) => {
        // 3. 判断是否执行 SQL 语句失败
        if (err) return res.cc(err)

        // 4.1 判断数据的 length
        if (results.length === 1) {
            const sql = `update carts set good_num = good_num + ? where good_id=?`
            db.query(sql, [req.body.good_num, req.body.good_id], (err, results) => {
                if (err) return res.cc(err)
                if (results.affectedRows !== 1) return res.cc('更新添加购物车数量失败！')
                res.cc('更新添加购物车数量成功！', 0)
            })
        }
        else {
            // 定义插入购物车的 SQL 语句
            const sql = `insert into carts set ?`
            // 执行插入购物车的 SQL 语句
            db.query(sql, req.body, (err, results) => {
                if (err) return res.cc(err)
                if (results.affectedRows !== 1) return res.cc('添加购物车失败！')
                res.cc('添加购物车成功！', 0)
            })
        }
    })
}





exports.updatecartById = (req, res) => {
    // 定义查重的 SQL 语句
    const sql = `select * from carts where id=? and uid=? and good_id=?`
    // 调用 db.query() 执行查重的 SQL 语句
    db.query(sql, [req.body.id, req.body.uid, req.body.good_id], (err, results) => {
        // 执行 SQL 语句失败
        if (err) return res.cc(err)

        // 判断名称和别名被占用的4种情况
        if (results.length === 0) return res.cc('购物车里没有此商品')

        // 定义更新购物车的 SQL 语句
        const sql = `update carts set good_num=? where id=? and uid=? and good_id=?`
        // 执行更新购物车的 SQL 语句
        db.query(sql, [req.body.good_num, req.body.id, req.body.uid, req.body.good_id], (err, results) => {
            if (err) return res.cc(err)
            if (results.affectedRows !== 1) return res.cc('更新购物车失败！')
            res.cc('更新购物车成功！', 0)
        })
    })

}


exports.clearcart = (req, res) => {
    // 定义标记删除的 SQL 语句
    const sql = `delete from carts where uid=?;`
    // 调用 db.query() 执行 SQL 语句
    db.query(sql, [req.body.uid], (err, results) => {
        if (err) return res.cc(err)
        if (results.affectedRows !== 1) return res.cc('删除商品失败！')
        res.cc('删除商品成功！', 0)
    })
}




exports.savecart = (req, res) => {
    // console.log(typeof (req));
    // console.log(req.body);
    const schema = joi.array().items(joi.object({
        uid: joi.number().integer().required(),
        good_id: joi.number().integer().required().min(1),
        good_name: joi.string().required(), // 商品名称是字符串  
        good_num: joi.number().integer().min(1).required(), // 假设商品数量至少为1  
        good_price: joi.number().required().min(1), // 可以是整数或浮点数  
        good_img: joi.string().required(),
    })).required()
    const result = schema.validate(req.body)
    // console.log("==============");
    // // console.log(result);
    // // console.log(result.error);
    // console.log("==============");
    if (!result.error) {
        // 定义标记删除用户的 SQL 语句
        const sql = `delete from carts where uid=?`
        // 调用 db.query() 执行 SQL 语句
        db.query(sql, [req.body[0].uid], (err, results) => {
            if (err) return res.cc(err)
            // console.log(sql);

            // 假设 req.body 是一个包含多个购物车条目对象的数组  
            const cartItems = req.body;

            // 构建插入语句和占位符  
            const sqlInsert = 'INSERT INTO carts (uid, good_id,good_name,good_price,good_num,good_img) VALUES ?';
            const values = cartItems.map(item => [item.uid, item.good_id, item.good_name, item.good_price, item.good_num,item.good_img]);

            db.query(sqlInsert, [values], (err, results) => {
                if (err) {
                    return res.status(500).json({ error: '更新失败', message: err.message });
                }

                // 注意：results.insertId 在批量插入时可能不是您想要的，因为它可能只返回最后一个插入的 ID  
                // 如果您需要每个插入的 ID，您可能需要使用数据库特定的功能或执行单独的插入操作  
                return res.status(201).json({ message: `成功更新购物车${results.affectedRows}条目数据` });
            });

        })
    } else {
        return res.status(500).json({ error: '更新失败', message: result.error });
    }







}
