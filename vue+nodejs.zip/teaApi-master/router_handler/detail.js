// 导入数据库操作模块
const db = require('../db/index')

// 获取商品基本信息的处理函数
exports.getdetail = (req, res) => {
  const id = req.query.id;  
  console.log(id); 
  // 定义查询商品信息的 SQL 语句
  const sql = `select * from goods where id=?`
  // 调用 db.query() 执行 SQL 语句
  db.query(sql, id, (err, results) => {
    // 执行 SQL 语句失败
    if (err) return res.cc(err)
    // 执行 SQL 语句成功，但是查询的结果可能为空
    if (results.length !== 1) return res.cc('获取商品信息失败！')

    // 商品信息获取成功
    res.send({
      status: 0,
      message: '获取商品信息成功！',
      data: results[0],
    })
  })
}
