// 这是路由处理函数模块 

// 导入数据库操作模块
const db = require('../db/index')
const joi = require('joi');


exports.addorder = (req, res) => {
    console.log(req.body);
    const { address, phone, totalPrice, cartItems, uid, name } = req.body;

    // 首先插入订单到orders表  
    const orderSql = 'INSERT INTO orders (money, address, phone, uid, name, Addtime) VALUES (?, ?, ?, ?, ?, NOW())';
    const orderValues = [totalPrice, address, phone, uid, name];

    db.query(orderSql, orderValues, (err, orderResults) => {
        if (err) {
            return res.status(500).json({ error: '添加订单时出错', message: err.message });
        }

        const orderId = orderResults.insertId; // 获取新插入的订单ID  

        // 然后为每个购物车项插入一条记录到order_items表  
        const itemPromises = cartItems.map(item => {
            const itemSql = 'INSERT INTO order_items (order_id, good_id, good_num) VALUES (?, ?, ?)';
            const itemValues = [orderId, item.good_id, item.good_num];
            return db.query(itemSql, itemValues);
        });

        // 使用Promise.all等待所有插入操作完成  
        Promise.all(itemPromises)
            .then(() => {
                // 所有订单项都已成功插入  
                res.status(201).json({ message: '订单已成功添加', order_id: orderId });
            })
            .catch(err => {
                // 处理插入订单项时的错误  
                // 注意：这里可能需要实现一些回滚逻辑，以确保在发生错误时不会留下不完整的订单记录  
                res.status(500).json({ error: '添加订单项时出错', message: err.message });
            });
    });
};




exports.getuserorderById = (req, res) => {
    const { uid } = req.params;
 
    // 注意：这里我们假设 orders 表包含 name, address, phone, money, oid 字段
    // 并且 order_items 表包含 good_id, good_num, order_id 字段
    const query = `
        SELECT o.name, o.address, o.phone, o.money, o.oid AS order_id, o.uid, oi.good_id, oi.good_num,Addtime,status
        FROM orders o
        LEFT JOIN order_items oi ON o.oid = oi.order_id
        WHERE o.uid = ?
    `;
    db.query(query, [uid], (err, results) => {
        if (err) {
            return res.status(500).json({ error: '查询订单时出错', message: err.message });
        }
 
        // 初始化一个空数组来存储订单对象
        let orders = [];
 
        // 使用一个 Map 来跟踪已经处理的订单，以避免重复
        const processedOrders = new Map();
 
        results.forEach(row => {
            const { name, address, phone, money, order_id, uid, good_id, good_num,Addtime,status} = row;
 
            // 如果这个订单还没有被处理过，就创建一个新的订单对象
            if (!processedOrders.has(order_id)) {
                processedOrders.set(order_id, {
                    name,
                    address,
                    phone,
                    money,
                    uid,
                    order_id, // 在订单对象中包含 order_id
                    Addtime,
                    cartItems: []
                });
                orders.push(processedOrders.get(order_id)); // 将新创建的订单对象添加到数组中
            }
 
            // 将订单项添加到当前订单的 cartItems 数组中
            // 注意：这里不需要再包含 order_id，因为它已经在订单对象级别定义了
            const order = processedOrders.get(order_id);
            order.cartItems.push({ good_id, good_num,status});
        });
 
        // 发送响应
        res.status(200).json({
            message: '成功获取订单',
            orders // 返回包含所有订单的数组
            // 如果只想返回一个订单（假设 uid 对应单个订单），可以使用：
            // (orders.length > 0 ? orders[0] : null)
        });
    });
};







exports.getmerchantOrderById = (req, res) => {
    const { mid } = req.params;

    // 三表联查，修正字段别名冲突
    const query = `
        SELECT 
            o.oid AS order_id,
            o.name AS receiver_name,  -- 修改别名以避免冲突
            o.address,
            o.phone,
            o.money,
            o.Addtime,
            oi.item_id,
            oi.good_id,
            oi.good_num,
            oi.status,
            g.name AS good_name  -- 修改商品名称为 good_name
        FROM orders o
        JOIN order_items oi ON o.oid = oi.order_id
        JOIN goods g ON oi.good_id = g.id
        WHERE g.mid = ?
        ORDER BY o.Addtime DESC
    `;

    db.query(query, [mid], (err, results) => {
        if (err) {
            return res.status(500).json({ error: '查询商家订单失败', message: err.message });
        }

        // 处理结果集
        const orderMap = new Map();

        results.forEach(row => {
            const orderId = row.order_id;
            
            if (!orderMap.has(orderId)) {
                orderMap.set(orderId, {
                    order_id: orderId,
                    receiver_name: row.receiver_name,
                    address: row.address,
                    phone: row.phone,
                    total_amount: row.money,
                    create_time: row.Addtime,
                    items: []
                });
            }

            orderMap.get(orderId).items.push({
                item_id: row.item_id,
                good_id: row.good_id,
                good_name: row.good_name,
                quantity: row.good_num,
                status: row.status
            });
        });

        // 将Map转为数组
        const orders = Array.from(orderMap.values());

        res.status(200).json({
            message: '成功获取商家订单',
            data: orders
        });
    });
};



exports.updatemerchantById = (req, res) => {
    console.log(req.body.item_id);
    
    // 定义查重的 SQL 语句
    const sql = `select * from order_items where item_id=? and order_id=? and good_id=?`
    // 调用 db.query() 执行查重的 SQL 语句
    db.query(sql, [req.body.item_id, req.body.order_id, req.body.good_id], (err, results) => {
        // 执行 SQL 语句失败
        if (err) return res.cc(err)

        // 判断名称和别名被占用的4种情况
        if (results.length === 0) return res.cc('订单里没有此商品')

        // 定义更新购物车的 SQL 语句
        const sql = `update order_items set status = ? where item_id=? and order_id=? and good_id=?`
        // 执行更新购物车的 SQL 语句
        db.query(sql, [req.body.status, req.body.item_id, req.body.order_id, req.body.good_id], (err, results) => {
            if (err) return res.cc(err)
            if (results.affectedRows !== 1) return res.cc('发货失败')
            res.cc('发货成功', 0)
        })
    })

}