// 导入数据库操作模块
const db = require('../db/index')
// 导入处理密码的模块
const bcrypt = require('bcryptjs')
const multiparty = require('multiparty');
const fs = require('fs');
const path = require('path');

// 获取用户基本信息的处理函数
exports.getUserInfo = (req, res) => {
  // 定义查询用户信息的 SQL 语句
  const sql = `select id, username, email, user_pic from user where id=?`
  // 调用 db.query() 执行 SQL 语句
  db.query(sql, req.query.id, (err, results) => {
    // 执行 SQL 语句失败
    if (err) return res.cc(err)
    // 执行 SQL 语句成功，但是查询的结果可能为空
    if (results.length !== 1) return res.cc('获取用户信息失败！')

    // 用户信息获取成功
    res.send({
      status: 0,
      message: '获取用户信息成功！',
      data: results[0],
    })
  })
}

// 更新用户基本信息的处理函数
exports.updateUserInfo = (req, res) => {
  // 定义待执行的 SQL 语句  

  const sql = `update user set ? where id=?`
  // 调用 db.query() 执行 SQL 语句并传递参数
  db.query(sql, [req.body, req.body.id], (err, results) => {
    // 执行 SQL 语句失败
    if (err) return res.cc(err)
    // 执行 SQL 语句成功，但是影响行数不等于 1
    if (results.affectedRows !== 1) return res.cc('更新用户的基本信息失败！')
    // 成功
    res.cc('更新用户信息成功！', 0)
  })
}

// 更新用户密码的处理函数
exports.updatePassword = (req, res) => {

  // 根据 id 查询用户的信息
  const sql = `select * from user where id=?`
  // 执行根据 id 查询用户的信息的 SQL 语句
  db.query(sql, req.body.id, (err, results) => {
    // 执行 SQL 语句失败
    if (err) return res.cc(err)
    // 判断结果是否存在
    if (results.length !== 1) return res.cc('用户不存在！')

    // 判断密码是否正确
    const compareResult = bcrypt.compareSync(req.body.oldPwd, results[0].password)
    if (!compareResult) return res.cc('旧密码错误！')

    // 定义更新密码的 SQL 语句
    const sql = `update user set password=? where id=?`
    // 对新密码进行加密处理
    const newPwd = bcrypt.hashSync(req.body.newPwd, 10)
    // 调用 db.query() 执行 SQL 语句
    db.query(sql, [newPwd, req.body.id], (err, results) => {
      // 执行 SQL 语句失败
      if (err) return res.cc(err)
      // 判断影响的行数
      if (results.affectedRows !== 1) return res.cc('更新密码失败！')
      // 成功
      res.cc('更新密码成功', 0)
    })
  })
}

// 更新用户头像的处理函数
// exports.updateAvatar = (req, res) => {
//   // router.post('/upload', (req, res) => {
//     console.log(req.body)
//     var form = new multiparty.Form();
//     form.parse(req, function (err, fields, files) {
//         try{
//             console.log(files)
//             var file = files.file[0]
//             console.log(file.path)
//             var data = fs.readFileSync(file.path)
//             console.log(data)
//             fs.writeFileSync(path.join(__dirname, '..', '/img', file.originalFilename), data)
//         }catch(err){
//             res.json({
//                 code:0,
//                 msessage:'文件上传失败:' + err
//             })
//             return
//         }
//         res.json({
//             code:200,
//             message:'文件上传成功',
//             url: '/img/' + file.originalFilename
//         })
//     // });
//   // console.log(req);
//   // // 1. 定义更新头像的 SQL 语句
//   // const sql = `update user set user_pic=? where id=?`
//   // // 2. 调用 db.query() 执行 SQL 语句
//   // db.query(sql, [req.body.avatar.name, req.body.id], (err, results) => {
//   //   // 执行 SQL 语句失败
//   //   if (err) return res.cc(err)
//   //   // 影响的行数是否等于 1
//   //   if (results.affectedRows !== 1) return res.cc('更换头像失败！')
//   //   // 成功
//   //   res.cc('更换头像成功！', 0)
//   })
// }




exports.updateAvatar = (req, res) => {
  const form = new multiparty.Form();
  form.parse(req, (err, fields, files) => {
    if (err) {
      return res.status(500).json({ code: 0, message: '文件解析失败: ' + err.message });
    }
    const userId = fields.id ? fields.id[0] : null;
    if (!userId) {
      return res.status(400).json({ code: 0, message: '用户ID缺失' });
    }
    const file = files.file ? files.file[0] : null;
    if (!file) {
      return res.status(400).json({ code: 0, message: '没有上传文件' });
    }
    const tempPath = file.path;
    const originalFilename = file.originalFilename;

    // 定义存储文件的路径（确保这个目录存在）
    const uploadDir = path.join(__dirname, '..', 'img', 'TX');
    const uploadPath = path.join(uploadDir, originalFilename);

    // 确保上传目录存在
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }

    const writeStream = fs.createWriteStream(uploadPath);
    const readStream = fs.createReadStream(tempPath);

    readStream.pipe(writeStream);

    writeStream.on('finish', () => {
      fs.unlinkSync(tempPath); // 删除临时文件

      // 构建头像的 URL
      const avatarUrl = `http://localhost:8081/img/TX/${originalFilename}`;

      // 更新数据库中的用户头像 URL
      new Promise((resolve, reject) => {
        const sql = `UPDATE user SET user_pic=? WHERE id=?`;
        db.query(sql, [avatarUrl, userId], (err, results) => {
          if (err) {
            reject(new Error('数据库查询失败: ' + err.message));
            return;
          }
          if (results.affectedRows !== 1) {
            reject(new Error('更新用户头像失败'));
            return;
          }
          resolve();
        });
      })
        .then(() => {
          res.json({
            code: 200,
            message: '文件上传成功',
            url: avatarUrl // 返回头像的 URL 给客户端
          });
        })
        .catch(err => {
          res.status(500).json({ code: 0, message: err.message });
        });
    });

    writeStream.on('error', err => {
      res.status(500).json({ code: 0, message: '文件写入失败: ' + err.message });
    });
  });
};






