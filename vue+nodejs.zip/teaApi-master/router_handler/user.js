// 导入数据库操作模块
const db = require('../db/index')
// 导入 bcryptjs 这个包
const bcrypt = require('bcryptjs')
// 导入生成 Token 的包
const jwt = require('jsonwebtoken')
// 导入全局的配置文件
const config = require('../config')
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// 确保上传目录存在
const uploadDir = path.join(__dirname, '..', 'img', 'merchant');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage }).single('license');




exports.regmerchant = (req, res) => {
  upload(req, res, (err) => {
    if (err) {
      return res.status(400).json({ message: '文件上传失败: ' + err.message });
    }
    if (!req.file) {
      return res.status(400).json({ message: '没有上传文件' });
    }

    // 拼接前缀到图片路径
    const baseUrl = "http://localhost:8081";
    const uploadPath = `img/merchant/${path.basename(req.file.path)}`;
    const fullPictureUrl = `${baseUrl}/${uploadPath}`;

    // 从 req.body 中获取其他字段
    const { username, password: rawPassword, bond, role } = req.body;

    // 检查用户名是否已被占用
    const sqlStr = 'SELECT * FROM user WHERE username=?';
    db.query(sqlStr, [username], (err, results) => {
      if (err) {
        return res.status(500).json({ message: '数据库查询错误: ' + err.message });
      }
      if (results.length > 0) {
        return res.status(400).json({ message: '用户名被占用，请更换其他用户名！' });
      }

      // 用户名可用，加密密码
      const hashedPassword = bcrypt.hashSync(rawPassword, 10);

      // 构建 user 表的数据对象
      const userData = {
        username,
        password: hashedPassword,
        role,
      };

      // 插入用户数据
      const userSql = 'INSERT INTO user SET ?';
      db.query(userSql, userData, (err, userResults) => {
        if (err) {
          console.error('数据库错误:', err);
          return res.status(500).json({ message: '添加用户失败: ' + err.message });
        }

        const userId = userResults.insertId; // 获取插入的 user id

        // 构建 Merchant_License 表的数据对象
        const merchantLicenseData = {
          mid: userId, // 使用 user 表中的 id 作为外键
          license: fullPictureUrl,
          bond,
        };

        // 插入商家许可证数据
        const merchantLicenseSql = 'INSERT INTO Merchant_License SET ?';
        db.query(merchantLicenseSql, merchantLicenseData, (err, licenseResults) => {
          if (err) {
            console.error('数据库错误:', err);
            return res.status(500).json({ message: '添加商家许可证失败: ' + err.message });
          }

          if (licenseResults.affectedRows !== 1) {
            return res.status(500).json({ message: '添加商家许可证失败，影响行数不正确' });
          }

          res.json({
            status: 0,
            message: '添加用户和商家许可证成功！',
            data: { userId, licenseResults }
          });
        });
      });
    });
  });
};





exports.getmerchant = (req, res) => {
  const sql = `
    SELECT 
      u.id, 
      u.username, 
      u.role, 
      m.license, 
      m.bond 
    FROM 
      user u
    LEFT JOIN 
      Merchant_License m 
    ON 
      u.id = m.mid
    WHERE 
      u.role IN (4, 2)
    ORDER BY 
      u.id ASC
  `;
  db.query(sql, (err, results) => {
    // 1. 执行 SQL 语句失败
    if (err) {
      console.error(err); // 通常会在控制台输出错误信息以便调试
      return res.status(500).send({
        status: 1,
        message: '获取商家列表失败',
        error: err.message // 或者 err，取决于你想返回多少错误信息
      });
    }
    // 2. 执行 SQL 语句成功
    res.send({
      status: 0,
      message: '获取商家列表成功！',
      data: results,
    });
  });
}

exports.changeRole = (req, res) => {
  // 定义查重的 SQL 语句
  const sql = `select * from user where id=?`
  // 调用 db.query() 执行查重的 SQL 语句
  db.query(sql, [req.body.id], (err, results) => {
      // 执行 SQL 语句失败
      if (err) return res.cc(err)
      //没查到数据
      if (results.length === 0) return res.cc('没有此商家')
      // 定义更新商家的 SQL 语句
      const sql = `update user set role=? where id=?`
      // 执行更新商家的 SQL 语句
      db.query(sql, [req.body.role, req.body.id], (err, results) => {
          if (err) return res.cc(err)
          if (results.affectedRows !== 1) return res.cc('更新商家失败！')
          res.cc('更新商家成功！', 0)
      })
  })

}









// 注册新用户的处理函数
exports.regUser = (req, res) => {
  // 获取客户端提交到服务器的用户信息
  const userinfo = req.body
  // 对表单中的数据，进行合法性的校验
  // if (!userinfo.username || !userinfo.password) {
  //   return res.send({ status: 1, message: '用户名或密码不合法！' })
  // }

  // 定义 SQL 语句，查询用户名是否被占用
  const sqlStr = 'select * from user where username=?'
  db.query(sqlStr, userinfo.username, (err, results) => {
    // 执行 SQL 语句失败
    if (err) {
      // return res.send({ status: 1, message: err.message })
      return res.cc(err)
    }
    // 判断用户名是否被占用
    if (results.length > 0) {
      // return res.send({ status: 1, message: '用户名被占用，请更换其他用户名！' })
      return res.cc('用户名被占用，请更换其他用户名！')
    }
    // 调用 bcrypt.hashSync() 对密码进行加密
    userinfo.password = bcrypt.hashSync(userinfo.password, 10)
    // 定义插入新用户的 SQL 语句
    console.log(userinfo);
    const sql = 'insert into user set ?'
    // 调用 db.query() 执行 SQL 语句
    db.query(sql, { username: userinfo.username, password: userinfo.password, role: userinfo.role }, (err, results) => {
      // 判断 SQL 语句是否执行成功
      // if (err) return res.send({ status: 1, message: err.message })
      if (err) return res.cc(err)
      // 判断影响行数是否为 1
      // if (results.affectedRows !== 1) return res.send({ status: 1, message: '注册用户失败，请稍后再试！' })
      if (results.affectedRows !== 1) return res.cc('注册用户失败，请稍后再试！')
      // 注册用户成功
      // res.send({ status: 0, message: '注册成功！' })
      res.cc('注册成功！', 0)
    })
  })
}



// 登录的处理函数
exports.login = (req, res) => {
  // 接收表单的数据
  const userinfo = req.body
  // 定义 SQL 语句
  const sql = `select * from user where username=?`
  // 执行 SQL 语句，根据用户名查询用户的信息
  db.query(sql, userinfo.username, (err, results) => {
    // 执行 SQL 语句失败
    if (err) return res.cc(err)
    // 执行 SQL 语句成功，但是获取到的数据条数不等于 1
    if (results.length !== 1) return res.cc('登录失败！')

    // TODO：判断密码是否正确
    const compareResult = bcrypt.compareSync(userinfo.password, results[0].password)
    if (!compareResult) return res.cc('登录失败！')

    // TODO：在服务器端生成 Token 的字符串
    const user = { ...results[0], password: '', user_pic: '' }
    // 对用户的信息进行加密，生成 Token 字符串
    const tokenStr = jwt.sign(user, config.jwtSecretKey, { expiresIn: config.expiresIn })
    //获取用户id号


    const uid = results[0].id
    const user_pic = results[0].user_pic
    const role = results[0].role
    // 调用 res.send() 将 Token 响应给客户端
    res.send({
      status: 0,
      data: {
        userid: userinfo.username,
        token: 'Bearer ' + tokenStr,
        uid: uid,
        user_pic: user_pic,
        role: role
      },
      message: '登录成功！',
    })
  })
}



