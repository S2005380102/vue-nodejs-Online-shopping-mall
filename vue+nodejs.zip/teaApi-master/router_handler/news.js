//这是路由处理模块

//导入数据库处理模块
const db = require('../db/index')


// 新增文章的处理函数
exports.addnews = (req, res) => {
    // 定义插入文章的 SQL 语句
    const sql = `insert into news set ?`
    // 执行插入文章的 SQL 语句
    db.query(sql, req.body, (err, results) => {
        if (err) return res.cc(err)
        if (results.affectedRows !== 1) return res.cc('添加文章失败！')
        res.cc('添加文章成功！', 0)
    })
}


// 获取文章列表的处理函数
exports.getnews = (req, res) => {
    // 定义根据 ID 获取文章分类数据的 SQL 语句
    const sql = `select id,title,time from news`
    // 调用 db.query() 执行 SQL 语句
    db.query(sql, (err, results) => {
        if (err) return res.cc(err)
        if (results.length == 0) return res.cc('获取文章列表数据失败！')

        res.send({
            status: 0,
            message: '获取文章列表数据成功！',
            data: results,
        })
    })
}



// 根据 Id 获取文章详情的处理函数
exports.getnewsById = (req, res) => {
    // 定义根据 ID 获取文章详情数据的 SQL 语句
    const sql = `select * from news where id=?`
    // 调用 db.query() 执行 SQL 语句
    db.query(sql, req.params.id, (err, results) => {
        if (err) return res.cc(err)
        if (results.length == 0) return res.cc('获取文章数据失败！')
        res.send({
            status: 0,
            message: '获取文章数据成功！',
            data: results,
        })
    })
}


exports.updatenewsById = (req, res) => {
    console.log(req.body);
    // 定义查重的 SQL 语句
    const sql = `select * from news where id=?`
    // 调用 db.query() 执行查重的 SQL 语句
    db.query(sql, [req.body.id], (err, results) => {
        // 执行 SQL 语句失败
        if (err) return res.cc(err)
        //没查到数据
        if (results.length === 0) return res.cc('没有这条新闻')
        // 定义更新地址列表的 SQL 语句
        const sql = `update news set ? where id=?`
        // 执行更新文地址列表的 SQL 语句
        db.query(sql, [req.body, req.body.id], (err, results) => {
            if (err) return res.cc(err)
            if (results.affectedRows !== 1) return res.cc('更新新闻失败！')
            res.cc('更新新闻成功！', 0)
        })
    })

}



exports.deletenewsById = (req, res) => {
    console.log(req.body);
    // 定义标记删除的 SQL 语句
    const sql = `delete from news where id=?;`
    // 调用 db.query() 执行 SQL 语句
    db.query(sql, [req.body.id], (err, results) => {
        if (err) return res.cc(err)
        if (results.affectedRows !== 1) return res.cc('删除新闻失败！')
        res.cc('删除新闻成功！', 0)
    })
}