const db = require('../db/index')
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// 确保上传目录存在
const uploadDir = path.join(__dirname, '..', 'img', 'goods');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage }).single('picture');

exports.getgoodsRouter = (req, res) => {
    const sql = 'select * from goods order by id asc'
    db.query(sql, (err, results) => {
        // 1. 执行 SQL 语句失败
        if (err) return res.cc(err)
        // 2. 执行 SQL 语句成功
        res.send({
            status: 0,
            message: '获取商品列表成功！',
            data: results,
        })
    })
}


// 获取过审商品的列表数据
exports.agoods = (req, res) => {
    const sql = 'select * from goods WHERE type = 1  order by id asc'
    db.query(sql, (err, results) => {
        // 1. 执行 SQL 语句失败
        if (err) return res.cc(err)
        // 2. 执行 SQL 语句成功
        res.send({
            status: 0,
            message: '获取商品列表成功！',
            data: results,
        })
    })
}






exports.addgoods = (req, res) => {
    upload(req, res, (err) => {
        if (err) {
            return res.status(400).json({ message: '文件上传失败: ' + err.message });
        }
        if (!req.file) {
            return res.status(400).json({ message: '没有上传文件' });
        }

        // 从 req.body 中获取其他字段
        const { name, paddress, stock, price, type, mid } = req.body;

        // 拼接前缀到图片路径
        const baseUrl = "http://localhost:8081";
        const uploadPath = `img/goods/${path.basename(req.file.path)}`; // 使用模板字符串进行拼接
        const fullPictureUrl = `${baseUrl}/${uploadPath}`; // 直接拼接字符串
        // 构建完整的商品数据对象
        const goodsData = {
            name,
            paddress,
            stock: parseInt(stock), // 确保数值类型
            price: parseFloat(price),
            type,
            mid: parseInt(mid),
            picture:fullPictureUrl// 转换路径分隔符
        };

        const sql = `INSERT INTO goods SET ?`;
        db.query(sql, goodsData, (err, results) => {
            if (err) {
                console.error('数据库错误:', err);
                return res.status(500).json({ message: '添加商品失败: ' + err.message });
            }
            if (results.affectedRows !== 1) {
                return res.status(500).json({ message: '添加商品失败，影响行数不正确' });
            }
            res.json({
                status: 0,
                message: '添加商品成功！',
                data: results // 返回插入的数据以便前端使用
            });
        });
    });
};


exports.updategoodsById = (req, res) => {
    upload(req, res, (err) => {
        if (err) {
            // 处理文件上传错误
            return res.status(400).json({ message: '文件上传失败: ' + err.message });
        }
        // 如果不需要更新图片，则req.file可能为undefined
        let goodsImagePath = req.file ? req.file.path : req.body.picture; // 保留原图片路径或更新为新图片路径

        const goodsData = {
        };
        console.log("---------------------------------==================");

        // 如果上传了新图片，则更新goodsData中的picture字段
        if (req.file) {
            // goodsData.picture = goodsImagePath.replace(/\\/g, '/'); // 转换为正斜杠以避免潜在问题

                    // 拼接前缀到图片路径
            const baseUrl = "http://localhost:8081";
            const uploadPath = `img/goods/${path.basename(req.file.path)}`; // 使用模板字符串进行拼接
            const fullPictureUrl = `${baseUrl}/${uploadPath}`; // 直接拼接字符串
            goodsData.picture = fullPictureUrl

        }
        goodsData.name = req.body.name;
        goodsData.paddress = req.body.paddress
        goodsData.stock = req.body.stock;            // 确保数值类型
        goodsData.price = req.body.price; 
        goodsData.type = req.body.type;        
        // 添加商品ID到更新数据中（确保您从req.body中正确获取了ID）
        goodsData.id = req.body.id;
        goodsData.mid = req.body.mid; // 假设mid也是需要从req.body中获取的字段

        const sql = `UPDATE goods SET ? WHERE id=? AND mid=?`;
        console.log(goodsData);
        
        // 执行更新商品的 SQL 语句
        db.query(sql, [goodsData, req.body.id, req.body.mid], (err, results) => {
            if (err) return res.status(500).json({ message: '更新商品失败: ' + err.message });

            if (results.affectedRows !== 1) return res.status(400).json({ message: '更新商品失败！' });

            res.json({ message: '更新商品成功！' });
        });
    });
};

exports.approveById = (req, res) => {
    console.log(req.body);
    console.log(req.body.id);
    console.log(req.body.type);
    // 定义查重的 SQL 语句
    const sql = `select * from goods where id=?`
    // 调用 db.query() 执行查重的 SQL 语句
    db.query(sql, [req.body.id], (err, results) => {
        // 执行 SQL 语句失败
        if (err) return res.cc(err)
        //没查到数据
        if (results.length === 0) return res.cc('没有商品')
        // 定义更新type的 SQL 语句
        const sql = `update goods set type=? where id=?`
        // 执行更新type的 SQL 语句
        db.query(sql, [req.body.type, req.body.id], (err, results) => {
            if (err) return res.cc(err)
            if (results.affectedRows !== 1) return res.cc('审核失败！')
            res.cc('审核成功！', 0)
        })
    })

}



// 新增商品的处理函数
// exports.addgoods = (req, res) => {
//     // 定义插入商品的 SQL 语句
//     const sql = `insert into goods set ?`
//     // 执行插入商品的 SQL 语句
//     db.query(sql, req.body, (err, results) => {
//         if (err) return res.cc(err)
//         if (results.affectedRows !== 1) return res.cc('添加商品失败！')
//         res.cc('添加商品成功！', 0)
//     })
// }


// //更新商品
// exports.updategoodsById = (req, res) => {
//     // 定义查重的 SQL 语句
//     const sql = `select * from goods where id=? and mid=?`
//     // 调用 db.query() 执行查重的 SQL 语句
//     db.query(sql, [req.body.id, req.body.mid], (err, results) => {
//         // 执行 SQL 语句失败
//         if (err) return res.cc(err)
//         // 判断名称和别名被占用的4种情况
//         if (results.length === 0) return res.cc('没有此商品')
//         // 定义更新商品的 SQL 语句
//         const sql = `update goods set ? where id=? and mid=?`
//         // 执行更新商品的 SQL 语句
//         db.query(sql, [req.body,req.body.id, req.body.mid], (err, results) => {
//             if (err) return res.cc(err)
//             if (results.affectedRows !== 1) return res.cc('更新商品失败！')
//             res.cc('更新商品成功！', 0)
//         })
//     }) 
// } 

exports.delgoods = (req, res) => {
    // 定义标记删除的 SQL 语句
    const sql = `delete from goods where id=?;`
    // 调用 db.query() 执行 SQL 语句
    db.query(sql, [req.body.id], (err, results) => {
        if (err) return res.cc(err)
        if (results.affectedRows !== 1) return res.cc('删除商品失败！')
        res.cc('删除商品成功！', 0)
    })
}

