<template>
  <div class="Goods">
    <header class="clear">
      <span>商品管理</span>
      <button @click="showAddGoodsPopup" class="button1">添加商品</button>
    </header>
    <Tag :tagList="tagTextList" @indexChange="changeTag" />
    <div class="content">
      <ul class="clear">
        <li v-for="(item, index) in goodsList" :key="index">
          <img v-if="item && item.picture" :src="item.picture" alt="" />
          <span v-if="item && item.name">{{ item.name }}</span>
          <div>
            <button class="normalBtn" @click="editGoods(item.id)">编辑</button>
            <button @click="deleteGoods(item.id)" class="deleteBtn">
              删除
            </button>
          </div>
        </li>
      </ul>
    </div>

    <!-- 添加弹窗 -->
    <div v-if="popupShow" class="popup">
      <div class="popup-content">
        <h2>添加商品</h2>
        <form @submit.prevent="addGoods">
          <div>
            <label for="name">商品名称:</label>
            <input type="text" v-model="newGoods.name" required />
          </div>
          <div>
            <label for="paddress">地址:</label>
            <input type="text" v-model="newGoods.paddress" required />
          </div>
          <div>
            <label for="stock">库存:</label>
            <input type="number" v-model="newGoods.stock" required />
          </div>
          <div>
            <label for="price">价格:</label>
            <input type="number" v-model="newGoods.price" required />
          </div>
          <div>
            <label for="picture">图片:</label>
            <input type="file" @change="onFileChange('newGoods')" />
          </div>
          <button type="submit">提交</button>
          <button type="button" @click="closePopup">取消</button>
        </form>
      </div>
    </div>
    <!-- 编辑弹窗 -->
    <div v-if="editPopupShow" class="popup">
      <div class="popup-content">
        <h2>编辑商品</h2>
        <form @submit.prevent="updateGoods">
          <div>
            <label for="name">商品名称:</label>
            <input type="text" v-model="editingGoods.name" required />
          </div>
          <div>
            <label for="paddress">地址:</label>
            <input type="text" v-model="editingGoods.paddress" required />
          </div>
          <div>
            <label for="stock">库存:</label>
            <input type="number" v-model="editingGoods.stock" required />
          </div>
          <div>
            <label for="price">价格:</label>
            <input type="number" v-model="editingGoods.price" required />
          </div>
          <div>
            <label for="picture">图片:</label>
            <input type="file" @change="onFileChange('editingGoods')" />
            <img
              v-if="editingGoods.preview"
              :src="editingGoods.preview"
              alt="商品预览"
              style="max-width: 100px"
            />
          </div>
          <button type="submit">提交</button>
          <button type="button" @click="closeEditPopup">取消</button>
        </form>
      </div>
    </div>
  </div>
</template>
   
  <script>
import axios from "axios";
export default {
  name: "MerchantGoods",
  data() {
    return {
      tagTextList: [],
      goodsList: [],
      popupShow: false,
      editPopupShow: false, // 新增编辑弹窗显示状态
      newGoods: {
        name: "",
        paddress: "",
        stock: 0,
        price: 0,
        picture: null, // 用于存储文件对象
        picturePreview: "", // 用于存储预览图片的Base64字符串
        type: 0,
        mid: this.$store.getters.mid,
      },
      editingGoods: {
        picture: null, // 用于存储文件对象
        preview: "", // 用于存储预览图片的Base64字符串（仅在编辑时显示）
      }, // 新增用于存储正在编辑的商品信息
    };
  },
  created() {
    this.fetchProducts();
  },
  methods: {
    onFileChange(goodsType) {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          if (goodsType === "newGoods") {
            this.newGoods.picturePreview = e.target.result;
          } else if (goodsType === "editingGoods") {
            this.editingGoods.preview = e.target.result;
          }
        };
        reader.readAsDataURL(file);

        // 更新文件对象
        if (goodsType === "newGoods") {
          this.newGoods.picture = file;
        } else if (goodsType === "editingGoods") {
          this.editingGoods.picture = file;
        }
      }
    },

    async fetchProducts() {
      try {
        const response = await axios.get(
          "http://localhost:8081/my/goods/agoods"
        );
        this.goodsList = response.data.data.filter(good => good.mid === this.$store.getters.mid);
      } catch (error) {
        console.error("获取商品列表失败:", error);
      }
    },

    navTo(path) {
      this.$router.push(path);
    },

    showAddGoodsPopup() {
      this.popupShow = true;
      this.newGoods = {
        name: "",
        paddress: "",
        stock: 0,
        price: 0,
        picture: "",
        type: 0,
        mid: this.$store.getters.mid,
      }; // 重置表单数据
    },

    closePopup() {
      this.popupShow = false;
    },

    async addGoods() {
      const formData = new FormData();
      formData.append("name", this.newGoods.name);
      formData.append("paddress", this.newGoods.paddress);
      formData.append("stock", this.newGoods.stock);
      formData.append("price", this.newGoods.price);
      formData.append("type", this.newGoods.type);
      formData.append("mid", this.newGoods.mid);
      formData.append("picture", this.newGoods.picture);

      try {
        const response = await axios.post(
          "http://localhost:8081/my/goods/addgoods",
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );
        console.log("商品更新成功，准备关闭弹窗");
        this.goodsList.push(response.data.data); // 假设返回的数据中包含了新添加的商品信息
        this.closePopup();
        location.reload();
      } catch (error) {
        console.error("添加商品失败:", error);
      }
    },

    editGoods(id) {
      // 根据id找到要编辑的商品
      const goodsToEdit = this.goodsList.find((goods) => goods.id === id);
      if (goodsToEdit) {
        this.editingGoods = { ...goodsToEdit }; // 深拷贝商品信息到editingGoods
        this.editPopupShow = true; // 显示编辑弹窗
      }
    },

    closeEditPopup() {
      this.editPopupShow = false;
      this.editingGoods = {}; // 清空编辑商品信息
    },

    async updateGoods() {
      const formData = new FormData();
      formData.append("id", this.editingGoods.id);
      formData.append("name", this.editingGoods.name);
      formData.append("paddress", this.editingGoods.paddress);
      formData.append("stock", this.editingGoods.stock);
      formData.append("price", this.editingGoods.price);
      formData.append("type", 0); // 假设type字段在编辑时不需要改变
      formData.append("picture", this.editingGoods.picture);
      formData.append("mid", this.editingGoods.mid);

      try {
        await axios.post("http://localhost:8081/my/goods/upgoods", formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });
        this.closeEditPopup();
        location.reload();
      } catch (error) {
        console.error("更新商品失败:", error);
      }
    },

    async deleteGoods(id) {
      try {
        // 构造要发送的 JSON 数据
        const data = { id };
        // 发送 POST 请求删除商品
        await axios.post("http://localhost:8081/my/goods/delgoods", data);
        // 从本地 goodsList 数组中移除已删除的商品
        this.goodsList = this.goodsList.filter((item) => item.id !== id);
      } catch (error) {
        console.error("删除商品失败:", error);
      }
    },
  },
};
</script>

<style scoped lang="less">
.Goods {
  header {
    width: 100%;
    height: 40px;
    line-height: 40px;
    span {
      float: left;
    }
    button {
      float: right;
      background-color: #337da4;
      color: white;
      border: none;
      width: 80px;
      height: 30px;
      border-radius: 5px;
    }
  }
  .content {
    position: relative;
    // background-color: white;
    width: 100%;
    top: -2px;
    ul {
      padding: 10px;
      li {
        float: left;
        display: inline-block;
        width: 200px;
        height: 300px;
        text-align: center;
        margin-right: 20px;
        img {
          width: 100%;
          height: 200px;
          border: 1px solid black;
        }
        span {
          font-size: 13px;
          display: block;
          margin: 10px 0;
          color: black;
        }
        .normalBtn {
          width: 50px;
          height: 25px;
          color: black;
          border: 1px solid black;
          background-color: white;
          border-radius: 5px;
          margin-right: 5px;
        }
        .deleteBtn {
          width: 50px;
          height: 25px;
          color: black;
          border: 1px solid black;
          background-color: white;
          border-radius: 5px;
        }
        .addGoods {
          width: 100%;
          height: 200px;
          text-align: center;
          cursor: pointer;
          border: 1px solid black;
          color: black;
          div {
            margin: 50px auto 10px;
            border-radius: 50%;
            border: 2px solid black;
            width: 40px;
            height: 40px;
            font-size: 30px;
            text-align: center;
            line-height: 30px;
          }
        }
        &:last-of-type {
          margin-right: 0;
        }
      }
    }
  }
  .popupContent {
    padding: 20px;
    input {
      display: block;
      width: 200px;
      height: 30px;
      border: none;
      border-bottom: 2px solid #333333;
      margin-top: 20px;
    }
    button {
      display: block;
      margin: 30px auto 0;
      background-color: #333333;
      color: white;
      border: none;
      width: 80px;
      height: 30px;
      border-radius: 5px;
    }
  }
}
</style>
<style scoped>
/* 添加一些基本的样式 */
.popup {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
}

.popup-content {
  background: white;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  width: 300px;
  text-align: center;
}

.popup-content form div {
  margin-bottom: 15px;
}

.popup-content form label {
  display: block;
  margin-bottom: 5px;
}

.popup-content form input {
  width: 100%;
  padding: 8px;
  box-sizing: border-box;
}

.popup-content form button {
  padding: 10px 20px;
  margin: 5px;
}
.button1 {
  margin-right: 20px;
}
</style>