<template>
  <div class="Backstage">
    <div class="bsLeft">
      <div class="logo">More Mall</div>
      <ul class="ulnav">
        <li
          @click="navTo('/MerchantGoods')"
          :class="{ selected: curPath === '/MerchantGoods' }"
        >
          商品管理
        </li>
        <li
          @click="navTo('/MerchantOrders')"
          :class="{ selected: curPath === '/MerchantOrders' }"
        >
          订单管理
        </li>
        <li
          @click="navTo('/MerchantProcess')"
          :class="{ selected: curPath === '/MerchantProcess' }"
        >
          审核进度
        </li>
        <li
          @click="navTo('/MerchantEdit')"
          :class="{ selected: curPath === '/MerchantEdit' }"
        >
          修改资料
        </li>
      </ul>
    </div>
    <div class="bsRight">
      <div class="header">
        <div class="title">商家管理系统</div>
        <div v-if="merchant" class="userInfo">
          当前用户：
          <span @mouseover="showUserTips" @mouseout="closeUserTips">{{
            merchant
          }}</span>
          <span @click="logout">&nbsp;&nbsp;&nbsp;退出</span>
        </div>
        <div v-else class="userInfo">
          <span>
            <router-link to="/merchantLogin">去登录</router-link>
          </span>
        </div>
      </div>
      <transition name="router-fade" mode="out-in">
        <router-view
          :style="{
            overflowY: 'scroll',
            width: '100%',
            padding: '20px',
            backgroundColor: '#f6f5fa',
          }"
        ></router-view>
      </transition>
    </div>
  </div>
</template>

<script>
export default {
  name: "merchant_index",
  data() {
    return {
      curPath: this.$route.path, // 初始化当前路径为当前路由的路径
      merchant: null, // 初始化为 null 或从 store 中获取
      userTipsShow: false, // 可能需要添加这个数据来控制用户提示的显示
    };
  },
  watch: {
    // 监听路由变化以更新当前路径
    $route(to) {
      this.curPath = to.path;
    },
  },
  created() {
    // 在组件创建时从 store 获取 merchant 数据
    this.merchant = this.$store.getters.merchant
  },
  methods: {
    navTo(path) {
      this.$router.push(path);
    },
    logout() {
      // 实现注销逻辑
      this.$store.dispatch("clearmerchant");
      // this.$router.replace("/");
      this.$router.push("/"); // 或其他登录页面路由
    },
    showUserTips() {
      this.userTipsShow = true;
    },
    closeUserTips() {
      this.userTipsShow = false;
    },
  },
};
</script>

<style scoped lang="less">
.Backstage {
  overflow: hidden;
  display: flex;
  .ulnav {
    width: 100%;
    height: 1200px;
    padding: 0;
  }
  .bsLeft {
    width: 15%;
    height: 100%;
    display: inline-block;
    overflow: hidden;
    user-select: none;
    .logo {
      @mainColor: #5c8d89;
      width: 100%;
      height: 70px;
      background-color: @mainColor;
      color: white;
      font-size: 25px;
      overflow: hidden;
      text-align: center;
      line-height: 70px;
    }
    ul {
      list-style: none;
      width: 100%;
      background-color: #d3f6d1;
      li {
        @fontDefaultColor: #000000;
        width: 100%;
        color: @fontDefaultColor;
        height: 45px;
        line-height: 45px;
        cursor: pointer;
        padding: 0 70px;
      }
      .selected {
        background-color: #a7d7c5;
        color: #000000;
      }
    }
  }
  .bsRight {
    width: 85%;
    height: 100%;
    display: inline-block;
    overflow: hidden;
    .header {
      @borderColor: #000000;
      width: 100%;
      height: 70px;
      line-height: 70px;
      border-bottom: 1px solid @borderColor;
      font-size: 18px;
      position: relative;
      user-select: none;
      .title {
        @fontDefaultColor: #000000;
        font-size: 23px;
        position: absolute;
        left: 10px;
        vertical-align: middle;
        color: @fontDefaultColor;
      }
      .userInfo {
        position: absolute;
        right: 10px;
        font-size: 14px;
        span {
          cursor: pointer;
        }
        .userTips {
          @borderColor: #000000;
          position: absolute;
          top: 45px;
          right: 0;
          width: 66px;
          cursor: pointer;
          border: 1px solid @borderColor;
          background-color: white;
          li {
            width: 100%;
            height: 30px;
            text-align: center;
            line-height: 30px;
            border-bottom: 1px solid @borderColor;
          }
        }
      }
    }
  }
}
</style>