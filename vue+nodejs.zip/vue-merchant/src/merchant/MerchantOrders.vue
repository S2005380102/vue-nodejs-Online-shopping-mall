<template>
  <div class="Orders">
    <header class="clear">
      <span>订单管理</span>
    </header>
    <div class="content">
      <table class="ordersTable">
        <thead>
          <tr>
            <th>订单号</th>
            <th>收件人</th>
            <th>收货地址</th>
            <th>联系电话</th>
            <th>商品</th>
            <th>购买数量</th>
            <th>订单状态</th>
            <th>下单时间</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="(orderItem, index) in flatOrderList"
            :key="orderItem.order_id + '-' + index"
          >
            <td>{{ orderItem.order_id }}</td>
            <td>{{ orderItem.receiver_name }}</td>
            <td>{{ orderItem.address }}</td>
            <td>{{ orderItem.phone }}</td>
            <td>{{ orderItem.good_name }}</td>
            <td>{{ orderItem.quantity }}</td>
            <td>{{ orderItem.status === 0 ? "未发货" : "已发货" }}</td>
            <td>{{ new Date(orderItem.create_time).toLocaleString() }}</td>
            <td>
              <button
                v-if="orderItem.status === 0"
                class="normal"
                @click="
                  editOrder(
                    orderItem.item_id,
                    orderItem.order_id,
                    orderItem.good_id
                  )
                "
              >
                发货
              </button>
              <button v-if="orderItem.status === 1" class="normal" disabled>
                已发货
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
   
  <script>
import axios from "axios";

export default {
  name: "Merchant_Orders",
  components: {},
  data() {
    return {
      orderList: [], // 用于存储原始订单数据
      flatOrderList: [], // 用于存储展平后的订单数据，供表格显示
    };
  },
  methods: {
    async fetchOrders() {
      const mid = this.$store.getters.mid;
      try {
        const response = await axios.get(
          "http://localhost:8081/api/merchantorder/" + mid
        );
        this.orderList = response.data.data;
        console.log(response.data.data);
        this.flatOrderList = this.orderList.flatMap((order) => {
          return order.items.map((item) => ({
            ...item,
            order_id: order.order_id,
            receiver_name: order.receiver_name,
            address: order.address,
            phone: order.phone,
            create_time: order.create_time,
          }));
        });
      } catch (error) {
        console.error("Error fetching orders:", error);
      }
    },
    async editOrder(item_id, order_id, good_id) {
      console.log(item_id, order_id, good_id);

      const status = 1; // 假设1代表已发货状态
      try {
        const response = await axios.post(
          `http://localhost:8081/api/updateorder`,
          { item_id, order_id, good_id, status },
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );
        if (response.data.message === "发货成功") {
          const updatedItem = this.flatOrderList.find(
            (item) => item.item_id === item_id && item.order_id === order_id
          );
          if (updatedItem) {
            updatedItem.status = status;
          }
          console.log("Order shipped successfully:", response);
        } else {
          console.error("Error shipping order:", response.data.message);
        }
      } catch (error) {
        console.error("Error sending shipping request:", error);
      }
    },
  },
  mounted() {
    this.fetchOrders();
  },
};
</script>

<style scoped lang="less">
.Orders {
  header {
    width: 100%;
    height: 40px;
    line-height: 40px;
    span {
      float: left;
    }
  }
  .content {
    width: 100%;
    background-color: white;
    position: relative;
    top: -3px;
    padding: 5px;
    .ordersTable {
      width: 100%;
      th {
        text-align: center;
      }
      tbody {
        tr {
          td {
            max-width: 100px;
            min-width: 30px;
            text-align: center;
            button {
              display: block;
              overflow: hidden;
              margin: 0 auto;
              margin-bottom: 5px;
              min-width: 30px;
            }
          }
        }
      }
    }
  }
}
</style>