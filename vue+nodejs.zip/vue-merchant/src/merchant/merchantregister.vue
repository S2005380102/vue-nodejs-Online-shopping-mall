<template>
  <div class="merchantLogin">
    <div class="content">
      <h3>OnlineMall</h3>
      <p>商家注册系统</p>
      <input v-model="username" type="text" placeholder="账号" />
      <input v-model="password" type="password" placeholder="密码" />
      <input v-model="bond" type="text" placeholder="保证金" />
      <p style="float: left;margin-left: 20px;">*请上传商家营业执照</p>
      <input type="file" @change="onFileChange"  />
      <button @click="register()">注册</button>
      <p>已有账号？去<a href="/">登录</a></p>
    </div>
  </div>
</template>
 
<script>
import axios from "axios";
import FormData from "form-data";

export default {
  name: "merchantLogin",
  data() {
    return {
      username: "",
      password: "",
      selectedFile: null,
      role: 4, 
    };
  },
  methods: {
    onFileChange(event) {
      this.selectedFile = event.target.files[0];
    },
    async register() {
      if (!this.username || !this.password || !this.selectedFile || !this.bond) {
        alert("请填写所有必填字段并选择文件！");
        return;
      }

      const form = new FormData();
      form.append("username", this.username);
      form.append("password", this.password);
      form.append("role", this.role);
      form.append("bond", this.bond); 
      form.append("license", this.selectedFile);

      try {
        const response = await axios.post(
          "http://localhost:8081/api/regmerchant",
          form,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );

        const result = response.data;
        if (result.status === 0) {
          alert("上传信息成功，请联系或等待管理员审核信息");
          this.$router.push("/");
        } else {
          alert("注册失败：" + (result.message || "未知原因"));
        }
      } catch (error) {
        alert("注册失败：" + (error.response?.data?.message || error.message));
        console.error(error);
      }
    },
  },
};
</script>

<style scoped lang="less">
.merchantLogin {
  @bgColor: #f8f8f8;
  background-color: @bgColor;
  position: relative;
  height: 800px;
  width: 1450px;
  margin: 0;
  .content {
    width: 300px;
    height: 800px;
    position: absolute;
    top: 20%;
    left: 50%;
    margin-top: -180px;
    margin-left: -150px;
    text-align: center;
    overflow: hidden;
    h3 {
      @secondColor: #40514e;
      color: @secondColor;
      font-size: 50px;
    }
    p {
      @fontDefaultColor: #40514e;
      margin-top: 20px;
      color: @fontDefaultColor;
      margin-bottom: 20px;
    }
    input {
      @borderColor: #cfe1e3;
      border-radius: 0;
      box-shadow: none;
      background: #fff;
      padding: 14px;
      width: 80%;
      border: 1px solid @borderColor;
    }
    button {
      width: 90%;
      @secondColor: #71c9ce;
      background: @secondColor;
      box-shadow: none;
      border: 0;
      border-radius: 3px;
      line-height: 41px;
      color: #fff;
      cursor: pointer;
      margin-top: 20px;
    }
  }
}
</style> 
