<template>
  <div class="merchantLogin">
    <div class="content">
      <h3>OnlineMall</h3>
      <p>商家登录系统</p>
      <input v-model="username" type="text" placeholder="账号" />
      <input v-model="password" type="password" placeholder="密码" />
      <button @click="login()">登录</button>
      <p>没有账号？去<a href="/merchantregister">注册</a>一个</p>
    </div>
  </div>
</template>
 
<script>
export default {
  name: "merchantLogin",
  data() {
    return {
      username: "",
      password: "",
    };
  },
  methods: {
    async login() {
      const data = new URLSearchParams();
      data.append("username", this.username);
      data.append("password", this.password);
      try {
        const response = await fetch("http://localhost:8081/api/login", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: data,
        });

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const jsonData = await response.json();
        const { token, uid: mid, userid: merchant } = jsonData.data;
        console.log(jsonData);

        if (jsonData.status == "0" && jsonData.data.role === 4) {
          alert("登录失败，请联系或等待管理员审核信息");
          }
        if (jsonData.status == "0" && jsonData.data.role === 2) {
          console.log("欢迎回来");
          this.$store.commit("merchant/setMerchantInfo", {
            mid,
            merchant,
            token,
          });
          alert("欢迎回来，商家：" + merchant);
          this.$router.push("/merchant");
        } else {
          alert("登录失败，您不是商家。");
        }
      } catch (error) {
        alert("登录失败");
        console.log(error);
      }
    },
  },
};
</script>

<style scoped lang="less">
.merchantLogin {
  @bgColor: #f8f8f8;
  background-color: @bgColor;
  position: relative;
  height: 800px;
  width: 1450px;
  margin: 0;
  .content {
    width: 300px;
    height: 450px;
    position: absolute;
    top: 50%;
    left: 50%;
    margin-top: -180px;
    margin-left: -150px;
    text-align: center;
    overflow: hidden;
    h3 {
      @secondColor: #40514e;
      color: @secondColor;
      font-size: 50px;
    }
    p {
      @fontDefaultColor: #40514e;
      margin-top: 20px;
      color: @fontDefaultColor;
      margin-bottom: 20px;
    }
    input {
      @borderColor: #cfe1e3;
      border-radius: 0;
      box-shadow: none;
      background: #fff;
      padding: 14px;
      width: 80%;
      border: 1px solid @borderColor;
    }
    button {
      width: 90%;
      @secondColor: #71c9ce;
      background: @secondColor;
      box-shadow: none;
      border: 0;
      border-radius: 3px;
      line-height: 41px;
      color: #fff;
      cursor: pointer;
      margin-top: 20px;
    }
  }
}
</style> 
