<template>
  <div class="EditAdmin">
    <header class="clear">
      <span>修改密码</span>
    </header>
    <div class="content">
      <div class="inputBox">
        <span>原密码：</span>
        <input
          placeholder="请输入原密码"
          v-model="form.oldPwd"
          type="password"
        />
      </div>
      <div class="inputBox">
        <span>新密码：</span>
        <input
          placeholder="请输入新密码"
          v-model="form.newPwd"
          type="password"
        />
      </div>
      <div class="inputBox">
        <span>确认新密码：</span>
        <input
          type="password"
          placeholder="请再输入一次新密码"
          v-model="form.confirmPwd"
        />
      </div>
      <button @click="submitForm">确认修改</button>
      <p v-if="message">{{ message }}</p>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "Merchant_Edit",
  components: {
    
  },
  data() {
    return {
      form: {
        id: this.$store.getters.mid,
        username: this.$store.getters.merchant,
        oldPwd: "",
        newPwd: "",
      },
      message: "", // 添加 message 属性来显示消息
    };
  },
  methods: {
    async submitForm() {
      // 验证新密码和确认密码是否匹配
      if (this.form.newPwd !== this.form.confirmPwd) {
        this.message = "两次输入的新密码不一致，请重新输入。";
        return;
      }

      try {
        const response = await axios.post(
          "http://localhost:8081/my/updatepwd",
          this.form
        );
        console.log(response.data);
        if (response.data.status==0) {
          this.message = "密码修改成功！";
          // 清空密码字段，保留其他可能需要的字段（如 id, username）
          this.form.oldPwd = "";
          this.form.newPwd = "";
          this.form.confirmPwd = "";
        } else {
          this.message =
            "密码修改失败：" + (response.data.message || "未知错误");
        }
      } catch (error) {
        this.message = "提交失败，请稍后重试。";
        console.error(error);
      }
    },
  },
};
</script>

<style scoped lang="less">
.EditAdmin {
  header {
    width: 100%;
    height: 40px;
    line-height: 40px;
    span {
      float: left;
    }
  }
  .content {
    margin-top: 20px;
    width: 290px;
    text-align: center;
    .inputBox {
      text-align: left;
      margin-bottom: 20px;
      span {
        color: black;
        font-size: 13px;
        display: inline-block;
        width: 90px;
      }
      input {
      }
    }
    button {
      background-color: #337da4;
      color: white;
      border: none;
      width: 80px;
      height: 30px;
      border-radius: 5px;
      cursor: pointer;
    }
  }
}
</style>