<template>
  <div class="Orders">
    <header class="clear">
      <span>商品审核进度</span>
    </header>
    <div class="content">
      <table class="ordersTable">
        <thead>
          <tr>
            <th>商品ID</th>
            <th>商品名称</th>
            <th>商品产地</th>
            <th>添加时间</th>
            <th>库存</th>
            <th>单价</th>
            <th>图片</th>
            <th>审核状态</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="(item, index) in flatOrderList"
            :key="item.id + '-' + index"
          >
            <td>{{ item.id }}</td>
            <td>{{ item.name }}</td>
            <td>{{ item.paddress }}</td>
            <td>{{ new Date(item.ptime).toLocaleString() }}</td>
            <td>{{ item.stock }}</td>
            <td>{{ item.price }}</td>
            <td>
              <img
                v-if="item.picture"
                :src="item.picture"
                alt="商品预览"
                style="width: 50px; height: 50px"
              />
            </td>
            <td>
              {{
                item.type === 0
                  ? "审核中"
                  : item.type === 1
                  ? "审核成功"
                  : "审核失败"
              }}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
 
<script>
import axios from "axios";

export default {
  name: "Merchant_Process",
  data() {
    return {
      goodsList: [], // 用于存储从接口获取的商品数据
      flatOrderList: [], // 用于存储转换后的商品数据，供表格显示（在这个例子中，它与 goodsList 相同）
    };
  },
  created() {
    this.fetchGoodsData();
  },
  methods: {
    async fetchGoodsData() {
      try {
        const response = await axios.get(
          "http://localhost:8081/my/goods/goods"
        );
        this.goodsList = response.data.data.filter(good => good.mid === this.$store.getters.mid);
        this.flatOrderList = this.goodsList.map((good) => ({
          ...good,
          // 可以在这里添加任何需要的转换或计算属性
        }));
      } catch (error) {
        console.error("Failed to fetch goods data:", error);
      }
    },
  },
};
</script>

<style scoped lang="less">
.Orders {
  header {
    width: 100%;
    height: 40px;
    line-height: 40px;
    span {
      float: left;
    }
  }
  .content {
    width: 100%;
    background-color: white;
    position: relative;
    top: -3px;
    padding: 5px;
    .ordersTable {
      width: 100%;
      th {
        text-align: center;
      }
      tbody {
        tr {
          td {
            max-width: 100px;
            min-width: 30px;
            text-align: center;
            button {
              display: block;
              overflow: hidden;
              margin: 0 auto;
              margin-bottom: 5px;
              min-width: 30px;
            }
          }
        }
      }
    }
  }
}
</style>