//导入axios
// import axios from 'axios';
//通用键名
const INFO_KEY = 'hm_merchant_info'
//获取个人信息
export const getInfo = () => {
    const defaultObj = { mid: '' ,merchant: '', token: '',}
    const result = localStorage.getItem(INFO_KEY)
    return result ? JSON.parse(result) : defaultObj
}
//设置个人信息
export const setInfo = (obj) => {
    console.log('setInfo called with:', obj);
    console.log('INFO_KEY is:', INFO_KEY);
    localStorage.setItem(INFO_KEY, JSON.stringify(obj))
    console.log('setInfo called with:', obj);
    console.log('INFO_KEY is:', INFO_KEY);
}
//移除个人信息
export const removeInfo = () => {
    localStorage.removeItem(INFO_KEY)
}


