// import Vue from 'vue'
import { createStore } from 'vuex';
import merchant from './modules/merchant'
import {removeInfo } from '@/utils/storage'
// import createPersistedState from 'vuex-persistedstate';
//Vue2写法
// Vue.use(Vuex)


const store = createStore({
    //提供数据
    state: {

    },
    //扩展
    getters: {
        mid(state) {
            return state.merchant.merchantInfo.mid
        },
        merchant(state) {
            return state.merchant.merchantInfo.merchant
        }, 
         token(state) {
            return state.merchant.merchantInfo.token
        },
    },

    // //修改数方法
    mutations: {

    },
    // //if操作
    actions: {
        clearmerchant() {
            removeInfo();
        },
    },
    modules: {
        merchant
    },
    plugins: [ ],




})
export default store;
