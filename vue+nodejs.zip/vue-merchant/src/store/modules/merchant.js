
import {getInfo,setInfo} from '@/utils/storage'
// import axios from 'axios';
export default{
    namespaced:true,
    //提供数据
    state(){
        return{
            merchantInfo:getInfo()
        }
    },
    //修改数方法
    mutations:{
        //所有Mutations第一个参数是state
        setMerchantInfo(state,obj){
            state.MerchantInfo = obj;  
            setInfo(obj)
         }
    },
    //if操作
    actions: {
    },
    //扩展
    getters:{}
}
