
// import { from } from "core-js/core/array"
import { createWebHistory,createRouter } from "vue-router"
import store from "@/store"


const routes = [
    {
        name: 'merchantLogin',
        path: '/',
        component: () => import("@/merchant/merchantLogin.vue")
    },
    {
        name: 'merchantregister',
        path: '/merchantregister',
        component: () => import("@/merchant/merchantregister.vue")
    },
    {
        name: 'merchant_index',
        path: '/merchant',
        component: () => import("@/merchant/merchant.vue"),
        children: [
            {
                name: 'merchant_Goods',
                path: '/MerchantGoods',
                component: () => import("@/merchant/MerchantGoods.vue")
            },
            {
                name: 'Merchant_Orders',
                path: '/MerchantOrders',
                component: () => import("@/merchant/MerchantOrders.vue")
            },
            {
                name: 'Merchant_Process',
                path: '/MerchantProcess',
                component: () => import("@/merchant/MerchantProcess.vue")
            },
            {
                name: 'Merchant_Edit',
                path: '/MerchantEdit',
                component: () => import("@/merchant/MerchantEdit.vue")
            },
          ]
    },

]





const router = createRouter({
    history: createWebHistory(),
    routes
})


//导航守卫
//to 去哪
//from 哪里来
//放行？

const authUrls = ['/merchant','/MerchantGoods', '/MerchantOrders', '/MerchantEdit', '/MerchantProcess']


router.beforeEach((to, from, next) => {

    // console.log(to,from,next)
    //非权限页面放行
    if (!authUrls.includes(to.path)) {
        next();
        return

    }
    //权限页面，需要token
    const token = store.getters.token
    if (token) {
        next()
    } else {
        alert("请先登录");
        console.log(token)
        next('/')
    }

    console.log(token)

    
})











export default router




